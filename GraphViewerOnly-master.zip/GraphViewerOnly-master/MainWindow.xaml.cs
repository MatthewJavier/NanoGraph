﻿using nanoBT_2nd_for_Windows_GraphViewer.Constants;
using nanoBT_2nd_for_Windows_GraphViewer.Controllers;
using nanoBT_2nd_for_Windows_GraphViewer.Handlers;
using nanoBT_2nd_for_Windows_GraphViewer.Helpers;
using nanoBT_2nd_for_Windows_GraphViewer.Models;
using nanoBT_2nd_for_Windows_GraphViewer.Services;
using nanoBT_2nd_for_Windows_GraphViewer.UI;
using nanoBT_2nd_for_Windows_GraphViewer.ViewModels;
using OxyPlot;
using OxyPlot.Annotations;
using OxyPlot.Axes;
using OxyPlot.Series;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection.Metadata;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using CoreSeries = OxyPlot.Series;
using WpfSeries = OxyPlot.Wpf;
using System;



namespace nanoBT_2nd_for_Windows_GraphViewer
{
    public partial class MainWindow : Window
    {
        private static int _colorIndex = 0;

        private readonly List<CheckpointEntry> _checkpoints = new();
        private readonly Dictionary<PlotModel, List<CheckpointEntry>> _multiGraphCheckpoints = new();
        private readonly Dictionary<PlotModel, LineAnnotation> _multiGraphMarkers = new();

        private readonly Dictionary<PlotModel, CheckBox> _multiGraphMarkerToggles = new();
        private readonly Dictionary<CheckBox, WpfSeries.PlotView> _plotMap = new();
        private readonly Dictionary<PlotModel, LineAnnotation> _plotMarkers = new();
        private readonly Dictionary<string, CoreSeries.StairStepSeries> _seriesMap = new();
        private bool _fileTypeWarningShown = false;
        private bool _isOverlayMode = false;
        private bool _isPlaying = false;
        private Point _lastTouchPoint;
        private DateTime _lastTouchTime = DateTime.MinValue;
        private char _nextCheckpointLabel = 'A';
        private PlotModel _overlayModel = new();
        private string? _overlayYAxisUnit = null;
        private PlaybackController _playbackController;
        private LineAnnotation _playbackMarker;
        private DispatcherTimer _playTimer = new() { Interval = TimeSpan.FromMilliseconds(AppConstants.PlaybackTickInterval) };
        private bool _unitMismatchWarningShown = false;

        // 直前に表示したチェックポイント数
        private int _lastShownCheckpointCount = 0;

        // チェックポイントの最大数
        public const int MaxCheckpointCount = 3;

        // 差異表に表示する最大区間数（A-B, B-C）
        public const int MaxSegmentCount = MaxCheckpointCount - 1;

        // その画面の ViewModel クラスのメンバーとして
        public ObservableCollection<CheckpointRow> CheckpointRows { get; }
            = new ObservableCollection<CheckpointRow>();

        // 重ねグラフの最大数（3色×2種の線）
        private const int MaxOverlaySeriesCount = 6;

        // ズームリセットに使うキャッシュ
        private double _initialXMin;
        private double _initialXMax;
        private double _initialYMin;
        private double _initialYMax;

        // ドロップした項目を一時保存
        private readonly Stack<OxyPlot.Series.Series> _overlaySeriesStack = new Stack<OxyPlot.Series.Series>();

        // カスタム凡例用 ViewModel（画面表示中ずっと保持）
        private LegendViewModel _legendViewModel;

        // ▼ SelectionChangedの多重実行防止フラグ
        private bool _isSwitchingGraph = false;

        // ▼ Overlayの初期化済み判定
        private bool _overlayInitialized = false;

        // タッチ長押し判定用（開始時刻と開始位置を保持）
        private DateTime _touchStartTime;
        private Point _touchStartPoint;

        // Drop直後のTouchを無効化
        private bool _ignoreNextTouch;

        // ▼ ドラッグ判定用
        private bool _isDragging;

        // ▼ マルチタッチ中か（ズーム中判定）
        private bool _isMultiTouch;

        // ▼ 直前がマルチタッチだったか
        private bool _wasMultiTouch;

        // ▼ マニュアルウィンドウ保持
        private Window _manualWindow;

        // CSV出力用に保持する元ファイルパス
        private string _loadedFilePath;

        // ▼ タブレット環境向けタッチパン感度
        private const double TouchPanSensitivity = 5.0;

        private AppFlags appFlags = new()
        {
            NextCheckpointLabel = 'A',
            OverlayYAxisUnit = null,
            UnitMismatchWarningShown = false,
            IsOverlayMode = false,
            IsPlaying = false,
            FileTypeWarningShown = false
        };

        public MainWindow()
        {
            InitializeComponent();
            InitUIState();
            AttachUIEvents();
            PositionWindow();

            DataContext = this;
        }

        public MainWindow(List<DatastreamItem> items) : this()
        {
            PopulateGraphPanel(items);
        }

        // ▼ UIイベントを一括登録
        private void AttachUIEvents()
        {

            GraphModeSelector.SelectionChanged += GraphModeSelector_SelectionChanged;

            OverlayPlotView.AllowDrop = true;
            OverlayPlotView.Drop += OverlayPlot_Drop;
            OverlayPlotView.MouseDown += OverlayPlotView_MouseDown;
            OverlayPlotView.TouchDown += OverlayGraphPlot_TouchDown;
            OverlayPlotView.TouchUp += OverlayGraphPlot_TouchUp;
            OverlayPlotView.TouchMove += OverlayGraphPlot_TouchMove;

            GraphPanel.AllowDrop = false;
            GraphPanel.Drop += (s, e) => e.Handled = true;

            // ▼ ウィンドウ位置保存
            this.Closing += (s, e) =>
            {
                Properties.Settings.Default.WindowLeft = this.Left;
                Properties.Settings.Default.WindowTop = this.Top;
                Properties.Settings.Default.WindowWidth = this.Width;
                Properties.Settings.Default.WindowHeight = this.Height;

                // ▼ Window状態保存（最大化対応）
                Properties.Settings.Default.WindowState = this.WindowState.ToString();

                Properties.Settings.Default.Save();

            };

        }

        private void ClearAllCheckpointMarkers()
        {
            CheckpointRenderer.ResetAllCheckpoints(_overlayModel);

            _multiGraphCheckpoints.Clear(); // Optional: if you want to reset data too
            _nextCheckpointLabel = 'A';     // Reset label tracker in MainWindow
        }

        private void ClearCheckpointsForMode(bool isOverlay)
        {
            if (isOverlay)
            {
                CheckpointRenderer.ResetAllCheckpoints(_overlayModel);
            }
            else
            {
                foreach (var model in _multiGraphMarkers.Keys)
                {
                    CheckpointRenderer.ResetAllCheckpoints(model);
                }
            }

            var keysToRemove = _multiGraphCheckpoints
                .Where(pair => pair.Value.All(cp => cp.IsOverlay == isOverlay))
                .Select(pair => pair.Key)
                .ToList();

            foreach (var key in keysToRemove)
                _multiGraphCheckpoints.Remove(key);

            foreach (var pair in _multiGraphCheckpoints)
                pair.Value.RemoveAll(cp => cp.IsOverlay == isOverlay);
        }

        // 「データをリセット」をクリック
        private void ClearMenu_Click(object sender, RoutedEventArgs e)
        {
            // 起動時と同じ状態にする
            var newWindow = new MainWindow();
            newWindow.Show();

            this.Close();
        }


        // 「簡易マニュアル」クリック時
        private void ManualMenu_Click(object sender, RoutedEventArgs e)
        {
            var path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "manual.txt");

            string text;

            if (System.IO.File.Exists(path))
            {
                text = System.IO.File.ReadAllText(path);
            }
            else
            {
                text = "マニュアルファイルが見つかりません";
            }

            // ▼ 既に開いている場合は再利用
            if (_manualWindow != null)
            {
                _manualWindow.Activate(); // 前面へ
                return;
            }

            // ▼ 新規作成
            _manualWindow = new Window
            {
                Title = "簡易マニュアル",
                Width = 600,
                Height = 400,
                Background = Brushes.White
            };

            // ▼ 閉じたら参照をクリア
            _manualWindow.Closed += (s, ev) => _manualWindow = null;


            // ▼ スクロールビュー
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Margin = new Thickness(10)
            };

            // ▼ テキスト表示用
            var textBox = new TextBox
            {
                Text = text,
                IsReadOnly = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                AcceptsReturn = true,
                BorderThickness = new Thickness(0)
            };

            scroll.Content = textBox;
            _manualWindow.Content = scroll;

            // ▼ 表示
            _manualWindow.Show();
        }

        /// <summary>
        /// 「全削除」クリック時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ClearOverlayPlot_Click(object sender, RoutedEventArgs e)
        {
            // クリアメソッドの呼び出し
            ClearOverlayPlotCore();

            // 再描画（モデルは再構築しない）
            _overlayModel.InvalidatePlot(false);

            MessageBox.Show(
                "オーバーレイグラフがクリアされました。\n続行するには新しいパラメーターをドラッグ＆ドロップしてください。",
                "オーバーレイのリセット",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }


        /// <summary>
        /// オーバーレイグラフの状態を完全にクリアする（実処理）
        /// </summary>
        private void ClearOverlayPlotCore()
        {
            _playbackController?.ResetPlayback();

            // === Undo を全件に対して適用するだけ ===
            foreach (var series in _overlayModel.Series.ToList())
            {
                UndoOneOverlaySeries(series);
            }

            // Undo 履歴だけは明示的にクリア
            _overlaySeriesStack.Clear();
        }


        /// <summary>
        /// 「一つ戻る」ボタンクリック時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UndoOverlay_Click(object sender, RoutedEventArgs e)
        {

            if (_overlaySeriesStack.Count == 0)
                return;

            // 最後に追加された series を取得
            var series = _overlaySeriesStack.Pop();

            // Undo の実処理
            UndoOneOverlaySeries(series);

            // ▼ VisualStateリセット用（確実に効く）
            this.Focus();

            // 再描画（モデルは再構築しない）
            _overlayModel.InvalidatePlot(false);

            Dispatcher.InvokeAsync(() =>
            {
                Mouse.Capture(null); // hover解除
            });


        }


        /// <summary>
        /// 指定された overlay series（DatastreamItem）について、グラフ・左側の表・軸状態を Undo する
        /// </summary>
        /// <param name="series"></param>
        private void UndoOneOverlaySeries(OxyPlot.Series.Series series)
        {
            // --- グラフから series を削除 ---
            _overlayModel.Series.Remove(series);

            // --- 左側の表を戻す ---
            if (series.Tag is DatastreamItem item)
            {
                // 固定枠 → 一覧へ戻す
                GraphPanelManager.UndoPinnedRow(
                    DataItemTable,
                    FixedAreaGrid,
                    item);
            }

            // --- 軸状態の調整 ---
            var leftAxis = _overlayModel.Axes.First(a => a.Key == "YL");
            var rightAxis = _overlayModel.Axes.First(a => a.Key == "YR");

            // Undo 時は必ずスケールキャッシュを破棄する
            leftAxis.Tag = null;
            leftAxis.MajorStep = double.NaN;
            leftAxis.MinorStep = double.NaN;

            rightAxis.Tag = null;
            rightAxis.MajorStep = double.NaN;
            rightAxis.MinorStep = double.NaN;

            // 右軸を使っている系列がまだあるか確認
            bool hasRightAxisSeries = _overlayModel.Series
                .OfType<OxyPlot.Series.LineSeries>()
                .Any(s => s.YAxisKey == "YR");

            // 右軸の系列が無くなったら、右軸を初期状態へ戻す
            if (!hasRightAxisSeries)
            {
                rightAxis.Title = string.Empty;
                rightAxis.IsAxisVisible = false;
                rightAxis.Tag = null;
                rightAxis.MajorStep = double.NaN;
                rightAxis.MinorStep = double.NaN;
            }

            // チェックポイント差分表を更新
            ShowCheckpointDurations();

            // 左軸まで空になった場合（クリアと同じ）
            if (_overlayModel.Series.Count == 0)
            {
                // 再計算せず、初回表示と同じ軸状態へ（Redo実装時に修正が必要）
                OverlayPlotManager.EnsurePlaybackMarker(_overlayModel, _playbackMarker);
                OverlayPlotManager.Setup(_overlayModel, OverlayPlotView, OverlayPanel, GraphPanel, _playbackMarker, OverlayPlot_Drop);

                // チェック消去メソッド呼び出し
                DeleteCheckpoint();

                // ガイドの表示状態を更新（データがあるときは表示）
                UpdateOverlayGuideVisibility();
            }

            // --- 表示領域を再計算 ---
            OverlayPlotManager.UpdateZoomPanState(_overlayModel);

            // Series 再構築後、凡例も作り直す（③）
            BuildLegendItemsFromSeries();

            // 要素なし（初期化時含む）の場合はエラー回避
            if (_legendViewModel.Items.Count > 0)
            {
                // 基準系列に応じて軸を更新（BaseClickのロジック共通化）
                ApplyAxisFromLegendItem(_legendViewModel.Items[0]);
            }
        }

        /// <summary>
        /// 「CSV出力」ボタンクリック時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExportCsv_Click(object sender, RoutedEventArgs e)
        {
            // --- データがない場合は何もしない ---
            if (CheckpointRows == null || !CheckpointRows.Any())
                return;

            // --- チェックポイント時間リストを取得 ---
            var relevant = _multiGraphCheckpoints.Values
                .SelectMany(x => x)
                .OrderBy(x => x.Time)
                .ToList();

            // CSV出力用の文字列を構築
            var sb = new StringBuilder();

            // ▼ 追加：header出力
            sb.AppendLine("[基本情報]");

            // 種別
            sb.AppendLine($"データ種別,{(PlotFactory.IsEdrData ? "EDR" : "データモニタ")}");

            // XML読み込み
            var doc = System.Xml.Linq.XDocument.Load(_loadedFilePath);

            // ▼ header取得（両対応）
            var header =
                doc.Root.Element("header") ??
                doc.Root.Element("savedata_dl")?.Element("header");

            // 各項目
            sb.AppendLine($"メーカー,{header?.Element("maker_id")?.Value}");
            sb.AppendLine($"車種,{header?.Element("car_model")?.Value}");
            sb.AppendLine($"取得日時,{header?.Element("save_date")?.Value}");
            sb.AppendLine($"元ファイル,{header?.Element("original_file")?.Value}");

            // ▼ EDRとmonitorで分岐
            if (PlotFactory.IsEdrData)
            {
                sb.AppendLine($"トリガー,{header?.Element("trigger")?.Value}");
                sb.AppendLine($"トリップ,{header?.Element("trip_name")?.Value}");

            }
            else
            {
                sb.AppendLine($"システム,{header?.Element("ecu_system")?.Value}");
            }

            sb.AppendLine(); // 空行

            // --- タイトル行を追加 ---
            sb.AppendLine("チェックポイント一覧");

            // --- A,B,C のヘッダを追加 ---
            sb.Append("項目");
            for (int i = 0; i < relevant.Count; i++)
            {
                sb.Append($",{(char)('A' + i)}");
            }
            sb.AppendLine();

            /* 時刻（秒）行を追加 */
            sb.Append("時刻(sec)");
            foreach (var cp in relevant)
            {
                sb.Append($",{cp.Time:0.00}");
            }
            sb.AppendLine();

            /* 時刻（時分秒）行を追加 */
            sb.Append("時刻(hh:mm:ss)");
            foreach (var cp in relevant)
            {
                var ts = TimeSpan.FromSeconds(cp.Time);
                sb.Append($",{ts:hh\\:mm\\:ss}");
            }
            sb.AppendLine();

            // --- ブロック区切りの空行 ---
            sb.AppendLine();

            // --- 差分ブロックタイトル ---
            sb.AppendLine("チェックポイント差分");

            // --- A-B, B-C ヘッダを追加 ---
            sb.Append("項目");
            int colCount = CheckpointRows[0].Values.Count;
            for (int i = 0; i < colCount; i++)
            {
                sb.Append($",{(char)('A' + i)}-{(char)('A' + i + 1)}間");
            }
            sb.AppendLine();

            // --- Δ時間（最初の行）を追加 ---
            var timeRow = CheckpointRows.First();
            sb.Append($"\"{timeRow.Label}\"");
            foreach (var val in timeRow.Values)
            {
                sb.Append($",{val:0.00}");
            }
            sb.AppendLine();

            // --- 残りの差分データをそのまま出力 ---
            foreach (var row in CheckpointRows.Skip(1))
            {
                sb.Append($"\"{row.Label}\"");
                foreach (var val in row.Values)
                {
                    sb.Append($",{val}");
                }
                sb.AppendLine();
            }

            // --- 保存ファイル名のデフォルト設定 ---

            // ▼ デフォルト名生成（headerベース）
            string defaultName = "checkpoint.csv";

            try
            {
                if (!string.IsNullOrEmpty(_loadedFilePath))
                {
                    // EDRの場合
                    if (System.IO.Path.GetFileName(_loadedFilePath).StartsWith("edr_", StringComparison.OrdinalIgnoreCase))
                    {
                        // tempファイル名をそのまま使う
                        defaultName = System.IO.Path.ChangeExtension(System.IO.Path.GetFileName(_loadedFilePath), ".csv");
                    }
                    // データモニタ
                    else
                    {
                        //var doc = System.Xml.Linq.XDocument.Load(_loadedFilePath);

                        //// ▼ header取得（両対応）
                        //var header =
                        //    doc.Root.Element("header") ??
                        //    doc.Root.Element("savedata_dl")?.Element("header");

                        var maker = header?.Element("maker_id")?.Value ?? "unknown";
                        var model = header?.Element("car_model")?.Value ?? "unknown";
                        var saveDate = header?.Element("save_date")?.Value;

                        // ▼ 禁止文字対策
                        maker = string.Concat(maker.Split(System.IO.Path.GetInvalidFileNameChars()));
                        model = string.Concat(model.Split(System.IO.Path.GetInvalidFileNameChars()));

                        // ▼ "/" 対応（重要）
                        maker = maker.Replace("/", "_");

                        // ▼ 日付変換
                        if (DateTime.TryParse(saveDate, out var dt))
                        {
                            defaultName = $"{maker}_{model}_{dt:yyyyMMdd_HHmmss}.csv";
                        }
                        else
                        {
                            defaultName = $"{maker}_{model}.csv";
                        }
                    }

                }
            }
            catch
            {
                // ▼ 失敗時は従来名
                defaultName = "checkpoint.csv";
            }

            // --- 保存ダイアログを表示 ---
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                FileName = defaultName
            };

            // --- ファイル保存 ---
            if (dlg.ShowDialog() == true)
            {
                File.WriteAllText(dlg.FileName, sb.ToString(), Encoding.UTF8);
            }
        }

        private PlaybackController CreatePlaybackController()
        {
            var bindings = new List<MarkerBinding>();

            // Overlay marker binding
            bindings.Add(new MarkerBinding
            {
                Model = _overlayModel,
                Marker = _playbackMarker,
                Toggle = null
            });

            // Multigraph marker bindings
            foreach (var (model, marker) in _multiGraphMarkers)
            {
                _multiGraphMarkerToggles.TryGetValue(model, out var checkbox);

                bindings.Add(new MarkerBinding
                {
                    Model = model,
                    Marker = marker,
                    Toggle = checkbox
                });
            }

            return new PlaybackController(
                TimeSlider,
                PlayPauseButton,
                bindings,
                nextValue =>
                {
                    // you already update the marker X here
                    // no need to touch unless you want custom logic
                },
                () =>
                {
                    _isPlaying = false;

                    PlayPauseButton.Content = AppConstants.PlaySymbol;
                }
            );
        }

        private LineAnnotation CreatePlaybackMarker()
        {
            return new LineAnnotation
            {
                Type = LineAnnotationType.Vertical,
                Color = AppConstants.PlaybackMarkerColor,
                LineStyle = LineStyle.Solid,
                StrokeThickness = AppConstants.CheckpointLineThickness
            };
        }

        // チェック消去をクリック
        private void DeleteCheckpointButton_Click(object sender, RoutedEventArgs e)
        {
            // チェック消去メソッド呼び出し
            DeleteCheckpoint();

            // 再描画して変更を反映させる
            _overlayModel.InvalidatePlot(false);

            // チェックポイント差分表を更新
            ShowCheckpointDurations();


        }

        // チェックポイントをすべて消去し、関連UIを初期状態に戻す
        private void DeleteCheckpoint()
        {
            // グラフ上のチェックポイントマーカーをすべて削除
            ClearAllCheckpointMarkers();

            // チェックポイント内部データをクリア
            _multiGraphCheckpoints.Clear();

            // チェックポイント差分表の行データをクリア
            CheckpointRows.Clear();

            // チェックポイント差分表の列をクリア
            CheckpointGrid.Columns.Clear();

            // チェックポイントラベルを初期状態に戻す
            _nextCheckpointLabel = 'A';
        }

        private void EnablePlaybackControls(List<DatastreamItem> items)
        {
            var allPoints = items.Where(i => i.Points.Count > 0).ToList();

            if (allPoints.Count > 0)
            {
                TimeSlider.Minimum = allPoints.Min(i => i.Points.Min(p => p.Time));
                TimeSlider.Maximum = allPoints.Max(i => i.Points.Max(p => p.Time));
                TimeSlider.Value = TimeSlider.Minimum;
                TimeSlider.IsEnabled = true;

                PlayPauseButton.IsEnabled = true;

                ResetPlaybackButton.IsEnabled = true;

                StepBackButton.IsEnabled = true;

                StepForwardButton.IsEnabled = true;

                DeleteCheckpointButton.IsEnabled = true;

                ResetGraphPositionButton.IsEnabled = true;
            }
        }

        /// <summary>
        /// 「マルチグラフ」と「重ねグラフ」の切り替え
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GraphModeSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (!IsLoaded || GraphModeSelector.SelectedIndex < 0) return;

            // グラフ切り替え処理呼び出し
            SwitchGraphMode(GraphModeSelector.SelectedIndex == 1);
        }


        // グラフモード切替メソッド（共通） 
        private void SwitchGraphMode(bool isOverlay)
        {
            // ▼ フラグで再実行を阻止
            if (_isSwitchingGraph) return;
            _isSwitchingGraph = true;

            // ▼ ロード中表示開始（モード切替前）
            LoadingOverlay.Visibility = Visibility.Visible;
            Dispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.Render);


            // ▼ ここから後ろを遅延実行にする
            Dispatcher.BeginInvoke(new Action(() =>
            {

                _playbackController?.ResetPlayback();

                _isPlaying = false;

                if (TimeSlider.Minimum < TimeSlider.Maximum)
                    TimeSlider.Value = TimeSlider.Minimum;

                // マルチグラフに変更
                if (!isOverlay)
                {

                    ClearOverlayPlotCore();

                    _isOverlayMode = false;

                    // ▼ 再生位置だけリセット（軽量）
                    foreach (var (model, marker) in _multiGraphMarkers)
                    {
                        marker.X = TimeSlider.Minimum;
                        model.InvalidatePlot(false);
                    }

                    // ▼ 表示切替（これが本体）
                    OverlayPanel.Visibility = Visibility.Collapsed;
                    GraphPanel.Visibility = Visibility.Visible;

                    // ▼ UI
                    OverlayToolbar.Visibility = Visibility.Collapsed;
                }
                // 重ねグラフに変更
                else
                {
                    // ▼ マルチのmarkerを事前に消す（1フレーム対策）
                    foreach (var marker in _multiGraphMarkers.Values)
                    {
                        marker.X = double.NaN; // ←表示外に飛ばす
                    }

                    // ▼ 即反映
                    foreach (var model in _multiGraphMarkers.Keys)
                    {
                        model.InvalidatePlot(false);
                    }

                    ClearCheckpointsForMode(false);

                    _isOverlayMode = true;

                    foreach (var cb in _multiGraphMarkerToggles.Values)
                        cb.IsChecked = false;

                    //OverlayPanel.Children.Clear();

                    // 初回のみセットアップ
                    if (!_overlayInitialized)
                    {
                        OverlayPlotManager.EnsurePlaybackMarker(_overlayModel, _playbackMarker);
                        OverlayPlotManager.Setup(_overlayModel, OverlayPlotView, OverlayPanel, GraphPanel, _playbackMarker, OverlayPlot_Drop);

                        _overlayInitialized = true;

                    }
                    // ▼ 表示切替（これが本体）
                    GraphPanel.Visibility = Visibility.Collapsed;
                    OverlayPanel.Visibility = Visibility.Visible;

                    //ボタン表示
                    OverlayToolbar.Visibility = Visibility.Visible;

                    // 差分表初期表示
                    Task.Run(() =>
                    {
                        var rows = BuildCheckpointRows(); // ←新しいメソッド

                        Dispatcher.BeginInvoke(() =>
                        {
                            ApplyCheckpointRows(rows);
                        });
                    });

                    // 再描画（モデルは再構築しない）
                    _overlayModel.InvalidatePlot(false);

                }

                // グラフモードに応じて凡例のスクロール可否を切り替える
                UpdateLegendScrollMode();

                // ▼ ロード中表示終了（最後）
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    LoadingOverlay.Visibility = Visibility.Collapsed;

                    // フラグ解除
                    _isSwitchingGraph = false;

                }), DispatcherPriority.Background);
            }), System.Windows.Threading.DispatcherPriority.Background);



        }

        /// <summary>
        /// チェックポイント差分表の行データを構築する新しいメソッド
        /// </summary>
        /// <returns></returns>
        private List<CheckpointRow> BuildCheckpointRows()
        {
            var rows = new List<CheckpointRow>();

            return rows;
        }

        /// <summary>
        /// チェックポイント差分表の行データを UI に適用する新しいメソッド
        /// </summary>
        /// <param name="rows"></param>
        private void ApplyCheckpointRows(List<CheckpointRow> rows)
        {
            CheckpointRows.Clear();
            foreach (var row in rows)
            {
                CheckpointRows.Add(row);
            }

            if (CheckpointRows.Count > 0)
            {
                BuildCheckpointColumns(Math.Min(CheckpointRows[0].Values.Count, MaxSegmentCount));
            }
        }

        // プロット上のマウス操作に応じてチェックポイントの追加・削除を処理する
        private void HandlePlotMouseDown(PlotModel model, double time, bool isOverlay)
        {
            // マルチグラフではチェックポイント操作を禁止
            if (!isOverlay)
            {
                return;
            }

            // Series が1本も無い場合はチェックポイントを作らない
            if (model == null || model.Series.Count == 0)
            {
                return;
            }


            bool isAdd =
                (!Mouse.LeftButton.Equals(MouseButtonState.Pressed)
                 && !Mouse.RightButton.Equals(MouseButtonState.Pressed))  // タッチ
                || Mouse.LeftButton == MouseButtonState.Pressed;          // 左クリック


            // 左クリック：チェックポイントを追加する
            if (isAdd)
            {

                // MAX チェックポイント数の判定（入口ガード）
                if (_multiGraphCheckpoints.TryGetValue(model, out var list))
                {
                    int count = list.Count(cp => cp.IsOverlay == isOverlay);

                    // 上限を超えた際には何もメッセージは出さずに終了
                    if (count >= MaxCheckpointCount)
                    {
                        return;
                    }
                }

                // グラフ上にチェックポイントを描画
                CheckpointRenderer.AddCheckpoint(time, model);

                // グラフごとのチェックポイント一覧を初期化
                if (!_multiGraphCheckpoints.ContainsKey(model))
                    _multiGraphCheckpoints[model] = new List<CheckpointEntry>();

                // チェックポイント情報を内部リストに追加
                _multiGraphCheckpoints[model].Add(new CheckpointEntry
                {
                    Time = time,
                    IsOverlay = isOverlay
                });
            }
            // 右クリック：最も近いチェックポイントを削除する
            else if (Mouse.RightButton == MouseButtonState.Pressed)
            {
                // 対象グラフにチェックポイントが存在する場合のみ処理
                if (_multiGraphCheckpoints.TryGetValue(model, out var checkpoints) && checkpoints.Any())
                {
                    // クリック位置に最も近いチェックポイントを特定
                    var nearest = checkpoints
                        .OrderBy(cp => Math.Abs(cp.Time - time))
                        .FirstOrDefault();

                    if (nearest != null)
                    {
                        // 内部リストからチェックポイントを削除
                        checkpoints.Remove(nearest);

                        // 表示用アノテーションのうち該当チェックポイントを特定
                        var targetTag = model.Annotations
                            .OfType<Annotation>()
                            .FirstOrDefault(a =>
                                a.Tag is Guid &&
                                (
                                    (a is LineAnnotation la && Math.Abs(la.X - nearest.Time) < 1e-6) ||
                                    (a is TextAnnotation ta && Math.Abs(ta.TextPosition.X - nearest.Time) < 1e-6)
                                )
                            )?.Tag;

                        // 特定したチェックポイントのアノテーションを一括削除
                        if (targetTag is Guid id)
                        {
                            model.Annotations
                                .Where(a => Equals(a.Tag, id))
                                .ToList()
                                .ForEach(a => model.Annotations.Remove(a));
                        }
                    }
                }
            }

            // A/B/C ラベルを時系列順に再割り当て
            CheckpointRenderer.ReassignCheckpointLabels(model);

            // チェックポイント差分の再計算・表示
            ShowCheckpointDurations();
        }

        private void InitUIState()
        {
            PlayPauseButton.IsEnabled = false;

            ResetPlaybackButton.IsEnabled = false;

            StepBackButton.IsEnabled = false;

            StepForwardButton.IsEnabled = false;

            TimeSlider.IsEnabled = false;

            DeleteCheckpointButton.IsEnabled = false;

            ResetGraphPositionButton.IsEnabled = false;

            // カスタム凡例 ViewModel を初期化する
            InitializeLegendViewModel();
        }

        // ▼ マルチグラフ上のクリック位置から時間を取得し、共通処理に渡す
        private void MultiGraphPlot_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // PlotViewまたはX軸が無効なら処理しない
            if (sender is not WpfSeries.PlotView plot || plot.Model?.DefaultXAxis == null)
                return;

            // クリック座標を時間軸の値に変換
            double time = plot.Model.DefaultXAxis.InverseTransform(e.GetPosition(plot).X);

            // 共通のクリック処理に委譲（マルチグラフとして処理）
            HandlePlotMouseDown(plot.Model, time, isOverlay: false);
        }

        // ▼ マルチグラフ上のダブルタップ位置から時間を取得し、共通処理に渡す
        private void MultiGraphPlot_TouchDown(object sender, TouchEventArgs e)
        {
            // PlotViewまたはX軸が無効なら処理しない
            if (sender is not WpfSeries.PlotView plot || plot.Model?.DefaultXAxis == null)
                return;

            // 現在のタップ情報を取得
            var currentTime = DateTime.Now;
            var currentPoint = e.GetTouchPoint(plot).Position;

            // 前回タップとの時間差と距離を計算
            var timeDiff = (currentTime - _lastTouchTime).TotalMilliseconds;
            var distance = Math.Sqrt(Math.Pow(currentPoint.X - _lastTouchPoint.X, 2) + Math.Pow(currentPoint.Y - _lastTouchPoint.Y, 2));

            // タップ状態を更新
            _lastTouchTime = currentTime;
            _lastTouchPoint = currentPoint;

        }

        // ▼ 重ねグラフ上のタップ位置から時間を取得し、共通処理に渡す
        private void OverlayGraphPlot_TouchDown(object sender, TouchEventArgs e)
        {

            // PlotViewを取得
            if (sender is not WpfSeries.PlotView plot)
                return;

            // タッチ開始位置と時間を記録（長押し判定用）
            _touchStartTime = DateTime.Now;
            _touchStartPoint = e.GetTouchPoint(plot).Position;

            // ▼ 現在の指の本数を取得（ズーム判定用）
            _isMultiTouch = plot.TouchesOver.Count() > 1;

            // ▼ ドラッグ状態リセット
            _isDragging = false;

        }

        // ▼ タップ終了時に「タップ or 長押し」を判定して処理する
        private void OverlayGraphPlot_TouchUp(object sender, TouchEventArgs e)
        {
            // PlotViewまたはX軸が無効なら処理しない
            if (sender is not WpfSeries.PlotView plot || plot.Model?.DefaultXAxis == null)
                return;

            // ▼ ズーム・パン中はタップ扱いしない
            if (_isDragging)
            {
                return;
            }

            // 要素ドロップ時は無効
            if (_ignoreNextTouch)
            {
                _ignoreNextTouch = false;
                return;
            }

            // ▼ タップ終了位置を取得
            var endPoint = e.GetTouchPoint(plot).Position;

            // ▼ 経過時間を計算（長押しかどうか）
            var elapsed = (DateTime.Now - _touchStartTime).TotalMilliseconds;

            // ▼ 移動距離を計算（ドラッグと区別するため）
            var distance = Math.Sqrt(
                Math.Pow(endPoint.X - _touchStartPoint.X, 2) +
                Math.Pow(endPoint.Y - _touchStartPoint.Y, 2));

            // ▼ グラフのX座標を時間に変換
            double time = plot.Model.DefaultXAxis.InverseTransform(endPoint.X);

            // ▼ 長押し（削除）
            if (elapsed > 400 && distance < 30)
            {
                // タッチ専用チエックポイント削除処理
                HandlePlotTouchDelete(plot.Model, time, isOverlay: true);
            }
            // ▼ 操作（ズーム・パン）はタップ扱いしない（これがないとズーム後にチェックポイントが付く）
            else if (elapsed > 150)
            {
                return;
            }
            // ▼ 通常タップ（追加）
            else
            {
                // チェックポイント追加処理
                HandlePlotMouseDown(plot.Model, time, isOverlay: true);
            }

            // ▼ グラフ再描画
            plot.Model.InvalidatePlot(false);

            // ▼ イベントの伝播を止める（重要）
            e.Handled = true;
        }

        // ▼ 1本指ドラッグでパン（ズームと分離）
        private void OverlayGraphPlot_TouchMove(object sender, TouchEventArgs e)
        {
            // PlotView取得
            if (sender is not WpfSeries.PlotView plot || plot.Model?.DefaultXAxis == null)
                return;

            // ▼ 2本指中はパンしない
            if (plot.TouchesOver.Count() > 1)
            {
                _wasMultiTouch = true;

                // ▼ ズーム中もドラッグ扱いにする
                _isDragging = true;

                return;
            }

            // ▼ ズーム直後ガード
            if (_wasMultiTouch)
            {
                _wasMultiTouch = false;

                // ▼ ズーム終了時に基準点をリセット（指を離した後に動くのを阻止）
                _touchStartPoint = e.GetTouchPoint(plot).Position;

                return;
            }

            var currentPoint = e.GetTouchPoint(plot).Position;

            // ▼ 移動量
            double dx = currentPoint.X - _touchStartPoint.X;

            // ▼ 小さい揺れは無視
            if (Math.Abs(dx) < 2)
                return;

            var xa = plot.Model.DefaultXAxis;

            // ▼ パン
            xa.Pan(dx);

            // ▼ 次の基準更新
            _touchStartPoint = currentPoint;

            // ▼ ドラッグ中フラグ
            _isDragging = true;

            plot.Model.InvalidatePlot(false);
        }

        // ▼ タッチ専用：チェックポイント削除処理
        private void HandlePlotTouchDelete(PlotModel model, double time, bool isOverlay)
        {
            // マルチグラフでは操作禁止
            if (!isOverlay)
                return;

            // チェックポイントが存在する場合のみ
            if (_multiGraphCheckpoints.TryGetValue(model, out var checkpoints) && checkpoints.Any())
            {
                // ▼ 最も近いチェックポイントを取得
                var nearest = checkpoints
                    .OrderBy(cp => Math.Abs(cp.Time - time))
                    .FirstOrDefault();

                if (nearest != null)
                {
                    // ▼ 内部リストから削除
                    checkpoints.Remove(nearest);

                    // ▼ アノテーションを特定
                    var targetTag = model.Annotations
                        .OfType<Annotation>()
                        .FirstOrDefault(a =>
                            a.Tag is Guid &&
                            (
                                (a is LineAnnotation la && Math.Abs(la.X - nearest.Time) < 1e-6) ||
                                (a is TextAnnotation ta && Math.Abs(ta.TextPosition.X - nearest.Time) < 1e-6)
                            )
                        )?.Tag;

                    // ▼ 関連アノテーションを一括削除
                    if (targetTag is Guid id)
                    {
                        model.Annotations
                            .Where(a => Equals(a.Tag, id))
                            .ToList()
                            .ForEach(a => model.Annotations.Remove(a));
                    }
                }
            }

            // ▼ ラベル再割り当て
            CheckpointRenderer.ReassignCheckpointLabels(model);

            // ▼ 差分更新
            ShowCheckpointDurations();
        }

        /// <summary>
        /// グラフに要素をドロップしたとき
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OverlayPlot_Drop(object sender, DragEventArgs e)
        {
            // マルチグラフの時は何もしない
            if (!_isOverlayMode)
            {
                e.Handled = true;
                return;
            }

            // PlotViewの外でDropされた場合は無効
            var pos = e.GetPosition(OverlayPlotView);

            if (pos.X < 0 || pos.Y < 0 ||
                pos.X > OverlayPlotView.ActualWidth ||
                pos.Y > OverlayPlotView.ActualHeight)
            {
                e.Handled = true;
                return;
            }

            // 表示するステータス数を制限
            if (_overlayModel.Series.Count >= MaxOverlaySeriesCount)
            {
                MessageBox.Show(
                    $"同時に表示できるステータスは最大 {MaxOverlaySeriesCount} 件までです。",
                    "表示数の上限",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                e.Handled = true;
                return;
            }

            // Drop直後のTouchを無効化
            _ignoreNextTouch = true;

            // OverlayグラフにファイルをDropしてデータ読込・UI更新を実行
            bool handled = OverlayFileDropHandler.HandleDrop(e,
                _overlayModel,
                OverlayPlotView,
                _overlaySeriesStack,

                // 各Item追加時のUI更新
                item =>
                    {
                        // ドロップされたアイテムを「固定エリア」に移動
                        GraphPanelManager.MoveRowToFixedArea(DataItemTable, FixedAreaGrid, item);

                        // 凡例（系列）が追加された瞬間に差異表を更新
                        ShowCheckpointDurations();
                    });

            /* Drop完了後に1回だけ全体リセット */
            if (handled && _overlayModel != null)
            {
                ResetAxes(_overlayModel);
            }

            // ここで凡例を再構築する（③）
            if (handled)
            {
                // ガイドの表示状態を更新（データがあるときは表示）
                UpdateOverlayGuideVisibility();

                // ズーム・パン時にチェックポイントを追従させる
                _overlayModel.Updated += (s, e) =>
                {
                    UpdateCheckpointAnnotationPositions();
                };

                BuildLegendItemsFromSeries();

                // 初期基準として1本目の凡例を▶にする
                if (_legendViewModel.Items.Any())
                {
                    ApplyAxisFromLegendItem(_legendViewModel.Items[0]);
                }
            }

            // グラフ再描画
            _overlayModel.InvalidatePlot(false);
        }

        // ズーム・パン時にチェックポイントの文字を常に画面上端に置き直す
        private void UpdateCheckpointAnnotationPositions()
        {
            if (_overlayModel == null)
                return;

            // 左Y軸を取得
            var yAxis = _overlayModel.Axes
                .FirstOrDefault(a => a.Position == AxisPosition.Left);

            if (yAxis == null)
                return;

            // 現在の画面上端（データ座標）
            double yTop = yAxis.ActualMaximum;

            // チェックポイント用 TextAnnotation だけを補正
            foreach (var annotation in _overlayModel.Annotations
                .OfType<TextAnnotation>()
                .Where(a => a.Tag is Guid))
            {
                // Xは変更せず、Yだけを上端へ
                var p = annotation.TextPosition;
                annotation.TextPosition = new DataPoint(p.X, yTop);
            }
        }

        private void OverlayPlotView_MouseDown(object sender, MouseButtonEventArgs e)
        {

            if (sender is not WpfSeries.PlotView plot || plot.Model?.DefaultXAxis == null)
                return;

            // グラフ外をダブルクリックしてもチックポイントが付いたため修正
            var model = plot.Model;
            var pos = e.GetPosition(plot);
            var screenPoint = new OxyPlot.ScreenPoint(pos.X, pos.Y);

            // グラフ外をダブルクリックの場合は無効
            if (!model.PlotArea.Contains(screenPoint))
            {
                // 凡例・余白・右側パネルなど → 何もしない
                return;
            }

            double time = plot.Model.DefaultXAxis.InverseTransform(e.GetPosition(plot).X);

            // プロット上のマウス操作に応じてチェックポイントの追加・削除を処理する
            HandlePlotMouseDown(_overlayModel, time, isOverlay: true);

            // 再描画して変更を反映させる
            _overlayModel.InvalidatePlot(false);

        }


        // ▼ データ一覧からマルチグラフを生成し、UIと操作イベントを初期化する
        private void PopulateGraphPanel(List<DatastreamItem> items)
        {
            // ▼ データ一覧を元にグラフ・UI（チェックボックス等）を一括生成
            GraphPanelManager.Populate(
                DataItemTable,
                FixedAreaGrid,
                GraphPanel,
                GraphModeSelector,
                PlayPauseButton,
                ResetPlaybackButton,
                StepBackButton,
                StepForwardButton,
                DeleteCheckpointButton,
                ResetGraphPositionButton,
                TimeSlider,
                items,
                _plotMap,

                // ▼ 各データ項目ごとにグラフモデルとUI要素を生成
                item => PlotFactory.CreateSynchronizedPlot(
                    item,
                    _plotMap.Count,

                    // ▼ 再生ライン（marker）をモデル単位で管理
                    (model, marker) => _multiGraphMarkers[model] = marker,

                    // ▼ チェックボックス（表示切替）をモデル単位で管理
                    (model, checkbox) => _multiGraphMarkerToggles[model] = checkbox),

                // ▼ チェックボックスのON/OFFイベントを登録
                (cb, h) => { cb.Checked += h; cb.Unchecked += h; }
            );

            // ▼ 各グラフにクリックイベントを設定（既存ハンドラを付け替え）
            foreach (var plotView in _plotMap.Values)
            {
                plotView.MouseDown -= MultiGraphPlot_MouseDown; // 重複登録防止
                plotView.MouseDown += MultiGraphPlot_MouseDown;
            }

            // ▼ 初期状態ではズーム・パン操作を無効化
            foreach (var model in _multiGraphMarkerToggles.Keys)
                PlotFactory.SetZoomEnabled(model, false);
        }

        // ウィンドウ位置設定（起動時）
        private void PositionWindow()
        {

            // ▼ 既存位置があればそれを使用
            if (Properties.Settings.Default.WindowWidth > 0)
            {
                var state = (WindowState)Enum.Parse(typeof(WindowState), Properties.Settings.Default.WindowState);

                // ▼ RestoreBoundsを正しく更新
                this.WindowState = WindowState.Normal;

                this.Left = Properties.Settings.Default.WindowLeft;
                this.Top = Properties.Settings.Default.WindowTop;
                this.Width = Properties.Settings.Default.WindowWidth;
                this.Height = Properties.Settings.Default.WindowHeight;

                // ▼ Window状態復元（最大化対応）
                // ▼ WindowStateはレイアウト確定後に適用
                // ※最大化までのタイムラグが気になるため保留
                //Dispatcher.BeginInvoke(() =>
                //{
                //    this.WindowState = state;
                //}, DispatcherPriority.ApplicationIdle);

                // ウィンドウが画面外に出てしまうパターンへの対策
                // ▼ 保存位置が画面内にあるかチェック
                var left = Properties.Settings.Default.WindowLeft;
                var top = Properties.Settings.Default.WindowTop;
                var Width = Properties.Settings.Default.WindowWidth;
                var Height = Properties.Settings.Default.WindowHeight;


                // 左上ポイント
                var rect = new Rect(left, top, Width, Height);

                // どれかのモニタに含まれているか
                bool isVisible = System.Windows.Forms.Screen.AllScreens
                    .Any(screen =>
                    {
                        var wa = screen.WorkingArea;
                        var screenRect = new Rect(wa.Left, wa.Top, wa.Width, wa.Height);
                        return screenRect.Contains(rect);
                    });

                // ▼ 左上が見えなければデフォルトへ
                if (!isVisible)
                {
                    goto DEFAULT_POSITION;
                }

                return;
            }

        DEFAULT_POSITION:

            var workArea = SystemParameters.WorkArea;

            Height = Math.Min(workArea.Height, 950);
            Width = Math.Min(workArea.Width, 1280);
            Top = workArea.Top;
            Left = (workArea.Width - Width) / 2 + workArea.Left;

        }

        // 「全体表示」クリック時
        private void ResetGraphPosition_Click(object sender, RoutedEventArgs e)
        {
            // オーバーレイグラフの表示範囲をリセットして1回だけ再描画する
            if (_overlayModel != null)
            {
                /* 全軸リセット＋X軸調整 */
                ResetAxes(_overlayModel);

                _overlayModel.InvalidatePlot(false);

            }
        }

        /* 軸リセット＋X軸目盛再設定 */
        private void ResetAxes(PlotModel model)
        {
            foreach (var axis in model.Axes)
            {
                axis.Reset();

                /* X軸のみステップ調整 */
                if (axis.Position == AxisPosition.Bottom && axis is LinearAxis xa)
                {
                    double range = xa.Maximum - xa.Minimum;
                    PlotFactory.ApplyTimeAxisStep(xa, range);
                }
            }
        }

        // チェックポイント間の時間差を計算し、差異表（時間行）を更新する
        private void ShowCheckpointDurations()
        {
            // 表データ（今は時間行だけ）
            var rows = new List<CheckpointRow>();

            // 重ねグラフ（OverlayPlotView）のモデルのみを差異表の対象とする
            if (OverlayPlotView.Model == null)
                return;

            List<CheckpointEntry> checkpoints = _multiGraphCheckpoints.TryGetValue(OverlayPlotView.Model, out var list)
                ? list
                : new List<CheckpointEntry>();

            // 表示対象（オーバーレイ条件一致）のチェックポイントを時刻順に取得
            var relevant = checkpoints
                    .Where(cp => cp.IsOverlay == _isOverlayMode)
                    .OrderBy(cp => cp.Time)
                    .ToList();

            // ▼ 時間行は常に表示する
            var timeRow = new CheckpointRow
            {
                Label = "時間（sec）"
            };

            // チェックポイントが2点未満の場合は時間のみ「ー」表示
            if (relevant.Count < 2)
            {
                CheckpointRows.Clear();

                // ▼ 区間数分だけ値を入れる
                for (int i = 0; i < MaxSegmentCount; i++)
                {
                    timeRow.Values.Add(null); // ← null でOK（表示は "-"）
                }

                // CSV出力ボタンを非表示にする
                CsvExport.Visibility = Visibility.Collapsed;

            }
            else
            {
                // CSV出力ボタンを表示にする
                CsvExport.Visibility = Visibility.Visible;
            }

            double total = 0;

            // 隣接するチェックポイント間の時間差を計算
            for (int i = 0; i < relevant.Count - 1; i++)
            {
                if (relevant.Count >= 2 && i < relevant.Count - 1)
                {
                    double diff = relevant[i + 1].Time - relevant[i].Time;
                    timeRow.Values.Add(diff);
                }
                else
                {
                    // A-B, B-C の時間差を時間行に追加
                    timeRow.Values.Add(null);
                }
            }

            // 表データに時間行を追加
            rows.Add(timeRow);

            // ▼ 列は必ず作る
            BuildCheckpointColumns(MaxSegmentCount);

            // ナンバリング用
            int index = 1;

            // Overlay 上の凡例系列を順に処理する（2～6項目対応）
            foreach (var series in OverlayPlotView.Model.Series
                .OfType<OxyPlot.Series.StairStepSeries>())
            {
                // 系列に DatastreamItem が紐づいていない場合は除外
                if (series.Tag is not DatastreamItem item)
                    continue;

                // 凡例名＋単位を行ラベルとする差異行を生成
                var legendRow = new CheckpointRow
                {
                    Label = $"[{index}] {item.Description}（{item.Unit}）"
                };

                // A-B, B-C の差異を最大区間数まで計算

                for (int i = 0; i < MaxSegmentCount; i++)
                {
                    if (relevant.Count >= 2 && i < relevant.Count - 1)
                    {
                        // チェックポイント時刻に最も近い系列値を取得
                        double v0 = GetSeriesValueAtTime(series, relevant[i].Time);
                        double v1 = GetSeriesValueAtTime(series, relevant[i + 1].Time);

                        // 差分値を凡例行に追加
                        legendRow.Values.Add(v1 - v0);

                    }
                    else
                    {
                        legendRow.Values.Add(null); // ← 追加
                    }

                }

                // 表データに凡例行を追加
                rows.Add(legendRow);

                index++;
            }

            // DataGrid にバインドするコレクションを更新
            CheckpointRows.Clear();
            foreach (var row in rows)
            {
                CheckpointRows.Add(row);
            }

            // 現在の時間行の要素数に応じて差異表の列（A-B, B-C）を再構築
            BuildCheckpointColumns(MaxSegmentCount);
        }

        // チェックポイントの差分値に応じて色を返す
        public class DiffToBrushConverter : IValueConverter
        {
            public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            {
                if (value == null)
                    return Brushes.Black;

                double v = (double)value;

                if (v > 0) return Brushes.IndianRed;    // 増加
                if (v < 0) return Brushes.SteelBlue;    // 減少

                return Brushes.Gray;                    // 変化なし
            }

            public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            {
                throw new NotImplementedException();
            }
        }

        /// <summary>
        /// 指定時刻に最も近いX値を持つポイントを全件ソートして先頭から取得
        /// </summary>
        /// <param name="series"></param>
        /// <param name="time"></param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException"></exception>
        private double GetSeriesValueAtTime(
                        OxyPlot.Series.Series series,
                        double time)
        {
            if (series is not OxyPlot.Series.LineSeries line)
                throw new InvalidOperationException("LineSeries only");

            // 指定時刻に最も近いX値のポイントを1回の走査で比較して取得（ソートを使わない高速版）
            var point = line.Points.Aggregate((a, b) =>
                Math.Abs(a.X - time) < Math.Abs(b.X - time) ? a : b);

            return point.Y;
        }


        // チェックポイント差分表の列（A-B, B-C）を構築する
        private void BuildCheckpointColumns(int segmentCount)
        {
            // 列が既にある場合は作り直さない
            if (CheckpointGrid.Columns.Count > 0)
                return;

            // 既存の列をクリア
            CheckpointGrid.Columns.Clear();

            // ▼ 行高さを自動にする
            CheckpointGrid.RowHeight = double.NaN;

            // 行ラベル列（時間 / 凡例など）
            CheckpointGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "項目",
                Width = new DataGridLength(2, DataGridLengthUnitType.Star),
                MinWidth = 70,

                Binding = new Binding(nameof(CheckpointRow.Label)),

                ElementStyle = new Style(typeof(TextBlock))
                {
                    Setters =
                    {
                        // 折り返し
                        new Setter(TextBlock.TextWrappingProperty, TextWrapping.Wrap),

                        // 最大3行
                        new Setter(TextBlock.MaxHeightProperty, 48.0),

                        // 省略
                        new Setter(TextBlock.TextTrimmingProperty, TextTrimming.CharacterEllipsis),

                        // 上寄せ
                        new Setter(TextBlock.VerticalAlignmentProperty, System.Windows.VerticalAlignment.Top),

                        // Tooltipで全文表示
                        new Setter(TextBlock.ToolTipProperty, new Binding(nameof(CheckpointRow.Label)))
                    }
                }
            });

            // A-B間, B-C間 ... の差異列
            for (int i = 0; i < segmentCount; i++)
            {
                char from = (char)('A' + i);
                char to = (char)('A' + i + 1);

                int index = i;

                CheckpointGrid.Columns.Add(new DataGridTextColumn
                {
                    Header = $"{from}-{to}間",


                    Width = new DataGridLength(1, DataGridLengthUnitType.Star),
                    MinWidth = 55,

                    Binding = new Binding($"Values[{index}]")
                    {
                        StringFormat = "0.##",
                        TargetNullValue = "-", // ← null のとき
                        FallbackValue = "-"    // ← バインド失敗時
                    },

                    ElementStyle = new Style(typeof(TextBlock))
                    {
                        Setters =
                        {
                            // はみ出し対策
                            new Setter(TextBlock.TextWrappingProperty, TextWrapping.NoWrap),
                            new Setter(TextBlock.TextTrimmingProperty, TextTrimming.CharacterEllipsis),
                            new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center),

                            // Tooltip
                            new Setter(TextBlock.ToolTipProperty, new Binding($"Values[{index}]")),
                                                        
                            // ▼ 数値を少し強調
                            new Setter(TextBlock.FontWeightProperty, System.Windows.FontWeights.SemiBold),

                            // ▼ 差分値に応じて文字色変更
                            new Setter(TextBlock.ForegroundProperty,
                                new Binding($"Values[{index}]")
                                {
                                    Converter = new DiffToBrushConverter()
                                }),

                        }
                    }
                });
            }
        }

        // 再生/一時停止ボタンクリック
        private void PlayPause_Click(object sender, RoutedEventArgs e)
        {
            _playbackController?.TogglePlayPause();

            _isPlaying = !_isPlaying;

            PlayPauseButton.ToolTip =
                _isPlaying ? "一時停止します" : "再生します";

        }

        // 停止ボタンクリック
        private void ResetPlayback_Click(object sender, RoutedEventArgs e)
        {
            _playbackController?.ResetPlayback();
        }


        // 一定時間戻るボタンクリック
        private void StepBack_Click(object sender, RoutedEventArgs e) => _playbackController?.StepBack();

        // 一定時間進むボタンクリック
        private void StepForward_Click(object sender, RoutedEventArgs e) => _playbackController?.StepForward();

        private void TimeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // Placeholder: Add logic here if you want to react to slider change
        }

        // 「アップロード」をクリック
        private void UploadMenu_Click(object sender, RoutedEventArgs e)
        {
            // ▼ ① ファイル選択
            var dialog = new Microsoft.Win32.OpenFileDialog();

            if (dialog.ShowDialog() != true)
            {
                return;
            }

            // 初回（未ロード）はそのまま
            if (string.IsNullOrEmpty(_loadedFilePath))
            {
                ExecuteUpload(dialog.FileName);
                return;
            }

            // 再読み込み時にリセット
            var newWindow = new MainWindow();
            newWindow.Show();
            this.Close();

            // ▼ ② 共通処理へ
            newWindow.ExecuteUpload(dialog.FileName);
        }


        // ▼ パス指定でアップロード処理
        public void ExecuteUpload(string path)
        {
            // ▼ パス保持（CSV用）
            _loadedFilePath = path;

            // 最初はマルチを非表示（チラつき防止）
            GraphPanel.Visibility = Visibility.Collapsed;
            OverlayPanel.Visibility = Visibility.Collapsed;

            // ▼ ファイル名でEDR判定
            var fileName = System.IO.Path.GetFileName(path);

            PlotFactory.IsEdrData = fileName.Contains("edr_", StringComparison.OrdinalIgnoreCase);


            // ▼ メニュー操作からデータアップロード＋UI初期構築を実行
            UploadMenuHandler.UploadMenuClick(
                this,
                DataItemTable,
                FixedAreaGrid,
                GraphPanel,
                GraphModeSelector,
                PlayPauseButton,
                ResetPlaybackButton,
                StepBackButton,
                StepForwardButton,
                DeleteCheckpointButton,
                ResetGraphPositionButton,
                TimeSlider,
                _plotMap,

                (item, isOverlay) => PlotFactory.CreateSynchronizedPlot(
                     item,
                     _plotMap.Count,
                     (model, marker) => _multiGraphMarkers[model] = marker,
                     (model, checkbox) => _multiGraphMarkerToggles[model] = checkbox,
                     isOverlay),

                (cb, h) => { cb.Checked += h; cb.Unchecked += h; },

                (trip, trigger) =>
                {
                    TripLabel.Text = $"トリップ：{trip}";
                    TriggerLabel.Text = $"トリガー：{trigger}";
                   // this.Title = $"nanoWIN グラフビューア: {trip}";
                },
                true,
                path // ← ★ここだけ将来使うために渡す（Handler側で対応する前提）
            );

            // ▼ 再生位置を示す縦線（PlaybackMarker）を新規作成
            _playbackMarker = new LineAnnotation
            {
                Type = LineAnnotationType.Vertical,
                Color = AppConstants.PlaybackMarkerColor,
                LineStyle = LineStyle.Solid,
                StrokeThickness = 2
            };

            // ▼ 再生制御（再生・停止・シーク）の初期化
            _playbackController = CreatePlaybackController();
            _playbackController.ResetPlayback();

            // ▼ 初期状態では再生ラインを非表示にする（再生時に表示される）
            foreach (var (model, marker) in _multiGraphMarkers)
                model.Annotations.Remove(marker);

            // ▼ 再生ボタンの表示を「再生アイコン」にリセット
            PlayPauseButton.Content = AppConstants.PlaySymbol;

            // ▼ 各グラフに対して入力イベント（マウス・タッチ）を設定
            foreach (var plotView in _plotMap.Values)
            {
                // 重複登録を防ぐため一度解除
                plotView.MouseDown -= MultiGraphPlot_MouseDown;

                // ▼ クリックでチェックポイント処理
                plotView.MouseDown += MultiGraphPlot_MouseDown;

                // ▼ タッチ操作でも同様に処理
                plotView.TouchDown += MultiGraphPlot_TouchDown;
                plotView.TouchUp += OverlayGraphPlot_TouchUp;
            }

            // ▼ アップロード直後はズーム・パン操作を無効化（デフォルト状態）
            foreach (var model in _multiGraphMarkerToggles.Keys)
                PlotFactory.SetZoomEnabled(model, false);

            // ▼ グラフモードを「重ねグラフ」を初期表示に変更
            SwitchGraphMode(true);

        }

        private void Window_DragOver(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.Copy;
            e.Handled = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _playbackMarker = CreatePlaybackMarker();

            _playbackController = CreatePlaybackController();

            // OxyPlotの既定凡例クリック（表示/非表示）を無効化する
            OverlayPlotView.Controller = new OxyPlot.PlotController();
        }


        /// <summary>
        /// ズーム制限用メソッド
        /// </summary>
        private void ApplyInitialZoomLimits()
        {
            foreach (var axis in _overlayModel.Axes)
            {
                double initialRange = axis.ActualMaximum - axis.ActualMinimum;

                if (initialRange <= double.Epsilon)
                    continue;

                if (axis.Position == AxisPosition.Bottom)
                {
                    // X軸（時間）
                    axis.MinimumRange = initialRange / 20.0; // 最大20倍拡大
                    axis.MaximumRange = initialRange * 2.0;  // 最大2倍縮小
                }
                else if (axis.Position == AxisPosition.Left ||
                         axis.Position == AxisPosition.Right)
                {
                    // Y軸（値）
                    axis.MinimumRange = initialRange / 10.0; // 最大10倍拡大
                    axis.MaximumRange = initialRange * 3.0;  // 最大3倍縮小
                }
            }
        }

        /// <summary>
        /// グラフの初期表示範囲を記憶する
        /// </summary>
        /// <param name="model"></param>
        private void CacheInitialRange(PlotModel model)
        {
            var xAxis = model.Axes
                .FirstOrDefault(a => a.Position == AxisPosition.Bottom);

            var yAxis = model.Axes
                .FirstOrDefault(a => a.Position == AxisPosition.Left);

            if (xAxis == null || yAxis == null)
                return;

            _initialXMin = xAxis.ActualMinimum;
            _initialXMax = xAxis.ActualMaximum;

            _initialYMin = yAxis.ActualMinimum;
            _initialYMax = yAxis.ActualMaximum;
        }

        /// <summary>
        /// カスタム凡例用 ViewModel を生成して UI に接続する
        /// </summary>
        private void InitializeLegendViewModel()
        {
            _legendViewModel = new LegendViewModel();

            // 凡例UI（ItemsControl / ListBox を置いた親）に DataContext を設定
            OverlayLegendHost.DataContext = _legendViewModel;
        }

        /// <summary>
        /// PlotModel 上の Series 情報を凡例 ViewModel に流し込む
        /// </summary>
        private void BuildLegendItemsFromSeries()
        {
            if (_legendViewModel == null)
                return;

            _legendViewModel.Items.Clear();

            // ナンバリング用
            int index = 1;

            // Overlay グラフに追加されている Series を列挙
            foreach (var series in OverlayPlotView.Model.Series
                                                      .OfType<LineSeries>())
            {
                // Series.Tag に入れている元データ（単位など）
                var dataItem = series.Tag as DatastreamItem;

                // 凡例1行分の ViewModel を作成
                var legendItem = new LegendItemViewModel(
                    name: $"[{index}] {series.Title}({dataItem.Unit})",    // 凡例表示名
                    unit: dataItem?.Unit ?? string.Empty, // 単位
                    series: series                     // 対応する Series
                );

                // 初期の表示状態を Series に合わせる
                legendItem.IsVisible = series.IsVisible;

                _legendViewModel.Items.Add(legendItem);

                index++;
            }
        }

        /// <summary>
        /// 凡例をスクロールさせないための抑止処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BlockLegendScroll(object sender, MouseWheelEventArgs e)
        {
            e.Handled = true;
        }

        /// <summary>
        /// グラフモードに応じて凡例のスクロール可否を切り替える
        /// </summary>
        private void UpdateLegendScrollMode()
        {
            if (OverlayLegendHost == null)
                return;

            // 0: マルチグラフ, 1: 重ねグラフ
            bool isMultiGraph = GraphModeSelector.SelectedIndex == 0;

            if (isMultiGraph)
            {
                // マルチグラフ：スクロール有効
                ScrollViewer.SetVerticalScrollBarVisibility(
                    RightPanelScrollViewer,
                    ScrollBarVisibility.Auto
                );

                OverlayLegendHost.PreviewMouseWheel -= BlockLegendScroll;
            }
            else
            {
                // 重ねグラフ：スクロール無効
                ScrollViewer.SetVerticalScrollBarVisibility(
                    RightPanelScrollViewer,
                    ScrollBarVisibility.Disabled
                );

                // マウスホイール・タッチスクロールも完全封じ
                OverlayLegendHost.PreviewMouseWheel += BlockLegendScroll;
            }
        }

        // 凡例の文字クリックで系列の表示／非表示を切り替える

        private void ToggleVisibleClick(object sender, MouseButtonEventArgs e)
        {
            // クリックされた凡例項目の ViewModel を取得
            if (sender is FrameworkElement fe &&
                fe.DataContext is LegendItemViewModel item)
            {
                // 凡例側の表示状態を反転
                item.IsVisible = !item.IsVisible;

                // 凡例が保持している Series の表示を切り替える
                item.Series.IsVisible = item.IsVisible;

                // 再描画して変更を反映
                item.Series.PlotModel?.InvalidatePlot(false);

                // クリックイベントはここで処理済みとする
                e.Handled = true;
            }
        }

        // ▷クリックで基準系列を切り替える

        private void BaseClick(object sender, MouseButtonEventArgs e)
        {
            // クリックされた凡例項目を取得
            if (sender is FrameworkElement fe &&
                fe.DataContext is LegendItemViewModel clickedItem)
            {

                // 軸処理を共通メソッドに委譲
                ApplyAxisFromLegendItem(clickedItem);

                // 再描画（モデルは再構築しない）
                _overlayModel.InvalidatePlot(false);

                // クリックイベントはここで処理済みとする
                e.Handled = true;
            }
        }


        // 基準系列に応じて軸を更新（BaseClickのロジック共通化）
        private void ApplyAxisFromLegendItem(LegendItemViewModel clickedItem)
        {

            // 全ての凡例を ▷ に戻す
            foreach (var item in _legendViewModel.Items)
                item.IsBase = false;

            // クリックされたものだけ ▶ にする
            clickedItem.IsBase = true;

            // この系列が使っているY軸（YL / YR）を判定
            bool useLeftAxis = clickedItem.Series.YAxisKey == "YL";

            // 左右Y軸を取得
            var leftAxis = _overlayModel.Axes
                .OfType<LinearAxis>()
                .First(a => a.Key == "YL");

            var rightAxis = _overlayModel.Axes
                .OfType<LinearAxis>()
                .First(a => a.Key == "YR");

            // 選択された系列が使っている軸を左に表示
            if (useLeftAxis)
            {
                // YL を左に表示
                leftAxis.Position = AxisPosition.Left;
                leftAxis.IsAxisVisible = true;

                rightAxis.IsAxisVisible = false;
                rightAxis.TextColor = OxyColors.Transparent;
                rightAxis.AxislineColor = OxyColors.Transparent;
                rightAxis.TicklineColor = OxyColors.Transparent;
                rightAxis.MajorGridlineColor = OxyColors.Transparent;
                rightAxis.MinorGridlineColor = OxyColors.Transparent;
            }
            else
            {
                // YR を左に表示
                rightAxis.Position = AxisPosition.Left;
                rightAxis.IsAxisVisible = true;
                leftAxis.IsAxisVisible = false;

                rightAxis.TextColor = OxyColors.Black;
                rightAxis.AxislineColor = OxyColors.Black;
                rightAxis.TicklineColor = OxyColors.Black;
                rightAxis.MajorGridlineColor = OxyColor.FromArgb(0x40, 0x00, 0x00, 0x00);
                rightAxis.MinorGridlineColor = OxyColor.FromArgb(0x20, 0x00, 0x00, 0x00);
            }

            // --- 未使用軸の単位が残らないよう両方クリア ---
            leftAxis.Title = null;   // 左軸の単位をクリア
            rightAxis.Title = null;  // 右軸の単位をクリア

            // 単位表示は選択された系列に合わせる
            var axis = useLeftAxis ? leftAxis : rightAxis;
            axis.Title = clickedItem.Unit;

            // --- 表示領域を再計算 ---
            OverlayPlotManager.UpdateZoomPanState(_overlayModel);

        }

        // ▼ Playback初期化（Populate後に呼ぶ）
        public void InitializePlaybackAfterPopulate()
        {
            // ▼ Playback初期化
            _playbackController = CreatePlaybackController();
            _playbackController.ResetPlayback();

            // ▼ マルチグラフのみ適用
            if (!_isOverlayMode)
            {
                // ▼ Zoom制御
                foreach (var model in _multiGraphMarkers.Keys)
                {
                    PlotFactory.SetZoomEnabled(model, false);
                }
            }
        }

        // ガイド表示制御
        internal void UpdateOverlayGuideVisibility()
        {
            OverlayGuide.Visibility =
                (_overlayModel.Series.Count == 0)
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

    }
}