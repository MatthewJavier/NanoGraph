﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nanoBT_2nd_for_Windows_GraphViewer.ViewModels
{
    public class CheckpointRow
    {

        // 項目名（"時間", "凡例1" など）
        public string Label { get; set; }  

        // 値
        public List<double?> Values { get; } = new();

    }
}
