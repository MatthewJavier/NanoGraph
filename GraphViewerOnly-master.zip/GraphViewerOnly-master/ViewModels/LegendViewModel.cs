﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Linq;
using OxyPlot.Series;

namespace nanoBT_2nd_for_Windows_GraphViewer.ViewModels
{
    // カスタム凡例全体を管理する ViewModel
    public class LegendViewModel
    {
        // 凡例に表示する項目一覧
        public ObservableCollection<LegendItemViewModel> Items { get; } = new();

        // 現在の基準項目
        public LegendItemViewModel? BaseItem { get; private set; }

        public int Index { get; set; }

        public string Label { get; set; } = "";

        public string DisplayName => $"[{Index}] {Label}";


    }
}
