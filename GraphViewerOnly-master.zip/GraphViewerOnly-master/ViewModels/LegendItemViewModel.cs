﻿using nanoBT_2nd_for_Windows_GraphViewer.Helpers;
using OxyPlot.Series;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;

namespace nanoBT_2nd_for_Windows_GraphViewer.ViewModels
{
    // 凡例1行（系列1本）の状態と操作を表す ViewModel
    public class LegendItemViewModel : INotifyPropertyChanged
    {
        public string Name { get; }
        public string Unit { get; }

        // 型を XYAxisSeries → LineSeriesBase に変更
        public LineSeries Series { get; }

        //public OxyPlot.OxyColor LineColor => Series.Color;
        public OxyPlot.LineStyle SeriesLineStyle => Series.LineStyle;

        public LegendItemViewModel(string name, LineSeries series)
        {
            Name = name;
            Series = series;
        }


        private bool _isVisible = true;
        public bool IsVisible
        {
            get => _isVisible;
            set { if (_isVisible == value) return; _isVisible = value; OnPropertyChanged(); }
        }

        private bool _isBase;
        public bool IsBase
        {
            get => _isBase;
            set { if (_isBase == value) return; _isBase = value; OnPropertyChanged(); }
        }

        // 項目名タップ：表示／非表示
        public ICommand ToggleVisibleCommand { get; }

        // ▷／▶タップ：基準切替
        public ICommand SetBaseCommand { get; }



        // 既存：色（そのまま）
        public Brush LineColor =>
            new SolidColorBrush(Color.FromArgb(
                Series.Color.A,
                Series.Color.R,
                Series.Color.G,
                Series.Color.B));

        // 既存ルール参照：実線 / 破線
        public DoubleCollection DashArray
        {
            get
            {
                // ★ 以前 Overlay で使っていた LineStyle をそのまま参照
                return SeriesLineStyle == OxyPlot.LineStyle.Dash
                    ? new DoubleCollection { 4, 2 }
                    : null; // Solid
            }
        }




        // 凡例1行分の ViewModel を初期化する
        public LegendItemViewModel(
            string name,
            string unit,
            LineSeries series)
        {
            Name = name;
            Unit = unit;
            Series = series;

            ToggleVisibleCommand = new RelayCommand(() =>
            {
                IsVisible = !IsVisible;
                Series.IsVisible = IsVisible;
                Series.PlotModel?.InvalidatePlot(false);
            });

        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));


    }


}