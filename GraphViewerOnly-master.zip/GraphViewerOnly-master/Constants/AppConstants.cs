﻿using OxyPlot;
using OxyPlot.Legends;

namespace nanoBT_2nd_for_Windows_GraphViewer.Constants
{
    public static class AppConstants
    {
        // Checkpoint Appearance
        public const double CheckpointLineThickness = 2.0;

        public const string CheckpointSymbol = "▼";

        public const double DefaultSliderMax = 1.0;

        // Slider Defaults
        public const double DefaultSliderMin = 0.0;

        // UI Messages
        public const string InvalidFileMessage = ".datastream ファイルのみ対応しています。";

        // Legend Styling
        public const bool IsLegendVisible = true;

        public const double LegendBorderThickness = 1.0;

        public const LegendOrientation legendOrientation = LegendOrientation.Vertical;

        public const LegendPlacement legendPlacement = LegendPlacement.Outside;

        public const LegendPosition legendPosition = LegendPosition.RightTop;

        // Marker Styling
        public const double MarkerStrokeThickness = 1.5;

        // Overlay Graph Defaults
        public const double OverlayGraphLineThickness = 2.5;

        public const double OverlayGraphMarkerSize = 2.0;

        public const MarkerType OverlayGraphMarkerType = MarkerType.None;

        public const string PauseSymbol = "⏸";

        // Playback Control
        public const double PlaybackTickInterval = 100.0;

        public const string PlaySymbol = "▶";

        public const string StepbackSymbol = "⏮";

        public const string StepforwardSymbol = "⏭";

        public const double StepSizeMilliseconds = 1000.0;

        // Axis Titles
        public const string TimeAxisTitle = "時間";

        public const string UnitMismatchMessageTemplate = "ユニット「{0}」の「{1}」は重ねグラフに追加できません。\n現在のY軸の単位は「{2}」です。";
        public const string ValueAxisTitle = "値";

        // ms

        public static readonly OxyColor CheckpointLineColor = OxyColors.DarkGray;

        public static readonly OxyColor CheckpointTriangleFill = OxyColors.DarkGreen;

        public static readonly OxyColor CheckpointTriangleStroke = OxyColors.Black;

        public static readonly OxyColor legendBackground = OxyColors.White;

        public static readonly OxyColor legendBorder = OxyColors.Black;

        // ms
        public static readonly OxyColor PlaybackMarkerColor = OxyColors.Black;

        // Multi-Graph Series Colors
        public static readonly OxyColor[] SeriesColorPalette =
        {
            OxyColors.Red,
            OxyColors.Blue,
            OxyColors.Green
        };

        // ▼ マルチグラフで同時に表示可能な最大数
        public const int MaxMultiGraphMarkers = 5;

        // ▼ 最小ズーム割合（全体の何％まで縮小可能か）
        public const double MinZoomRatio = 0.005; 

    }
}