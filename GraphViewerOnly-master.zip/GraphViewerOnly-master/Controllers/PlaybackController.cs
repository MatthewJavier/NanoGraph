﻿using nanoBT_2nd_for_Windows_GraphViewer.Constants;
using nanoBT_2nd_for_Windows_GraphViewer.Models;
using System.Windows.Controls;
using System.Windows.Threading;

namespace nanoBT_2nd_for_Windows_GraphViewer.Controllers
{
    public class PlaybackController
    {
        private readonly List<MarkerBinding> _markerBindings;
        private readonly Action _onPlaybackEnded;
        private readonly Action<double> _onTick;
        private readonly Button _playPauseButton;
        private readonly DispatcherTimer _playTimer;
        private readonly Slider _timeSlider;
        private bool _isPlaying = false;

        public PlaybackController(
            Slider timeSlider,
            Button playPauseButton,
            List<MarkerBinding> markerBindings,
            Action<double> onTick,
            Action onPlaybackEnded)
        {
            _timeSlider = timeSlider;
            _playPauseButton = playPauseButton;
            _markerBindings = markerBindings;
            _onTick = onTick;
            _onPlaybackEnded = onPlaybackEnded;

            _playTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(AppConstants.PlaybackTickInterval)
            };

            _playTimer.Tick += (s, _) => Tick();
        }

        public void StepBack()
        {

            // ▼ 追加：現在レンジの5%戻る
            double range = _timeSlider.Maximum - _timeSlider.Minimum;
            double step = range * 0.05;

            _timeSlider.Value = Math.Max(_timeSlider.Minimum, _timeSlider.Value - step);

            _onTick(_timeSlider.Value);
        }

        public void StepForward()
        {
            // ▼ 追加：現在レンジの5%進む
            double range = _timeSlider.Maximum - _timeSlider.Minimum;
            double step = range * 0.05;

            _timeSlider.Value = Math.Min(_timeSlider.Maximum, _timeSlider.Value + step);

            _onTick(_timeSlider.Value);
        }

        public void StopPlayback()
        {
            _isPlaying = false;

            _playPauseButton.Content = AppConstants.PlaySymbol;

            _playTimer.Stop();

            foreach (var b in _markerBindings)
                b.Model.Annotations.Remove(b.Marker);
        }

        public void ResetPlayback()
        {
            StopPlayback();                      // いまの Stop の処理
            _timeSlider.Value = _timeSlider.Minimum;
            _onTick(_timeSlider.Value);
        }

        public void TogglePlayPause()
        {
            _isPlaying = !_isPlaying;

            _playPauseButton.Content = _isPlaying ? AppConstants.PauseSymbol : AppConstants.PlaySymbol;

            if (!_isPlaying)
            {
                foreach (var b in _markerBindings)
                    b.Model.Annotations.Remove(b.Marker);
            }

            if (_isPlaying)
                _playTimer.Start();
            else
                _playTimer.Stop();
        }

        /// <summary>
        /// 再生タイマーに応じてスライダー値を更新し、各グラフの再生位置マーカーを同期する
        /// </summary>
        private void Tick()
        {
            // ▼ スライダー範囲に対する割合で進める（範囲に依存しない速度）
            double range = _timeSlider.Maximum - _timeSlider.Minimum;

            // ▼ 1Tickあたりの移動量（0.5%がおすすめ）
            double step = range * 0.005;

            // ▼ 次の再生位置
            double nextValue = _timeSlider.Value + step;

            // ▼ 再生位置が最大値に到達した場合は終了処理へ
            // ※ TickIntervalが大きいと一気にここに入る（EDRで端に飛ぶ原因）
            if (nextValue >= _timeSlider.Maximum)
            {
                // ▼ スライダーを最大値に固定
                _timeSlider.Value = _timeSlider.Maximum;

                // ▼ 再生状態をリセット
                ResetPlayback();

                // ▼ 再生終了通知
                _onPlaybackEnded();

                return;
            }

            // ▼ スライダー値を更新（再生位置を進める）
            _timeSlider.Value = nextValue;

            // ▼ 外部コールバックに現在位置を通知
            _onTick(nextValue);

            // ▼ 各グラフの再生位置マーカーを更新
            foreach (var binding in _markerBindings)
            {
                // ▼ チェックONの系列のみ更新（トグル未使用の場合も含む）
                if (binding.Toggle == null || binding.Toggle.IsChecked == true)
                {
                    // ▼ マーカーのX位置を現在再生位置に同期
                    binding.Marker.X = nextValue;

                    // ▼ 未追加ならAnnotationとしてモデルに登録
                    if (!binding.Model.Annotations.Contains(binding.Marker))
                        binding.Model.Annotations.Add(binding.Marker);

                    // ▼ 再描画（軽量更新）
                    binding.Model.InvalidatePlot(false);
                }
            }
        }
    }
}