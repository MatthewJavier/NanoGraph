﻿using System.Windows;
using System.Windows.Controls;
using OxyPlot;
using OxyPlot.Annotations;
using WpfSeries = OxyPlot.Wpf;
using nanoBT_2nd_for_Windows_GraphViewer.Constants;
using nanoBT_2nd_for_Windows_GraphViewer.Models;

namespace nanoBT_2nd_for_Windows_GraphViewer.Controllers
{
    public static class ApplicationResetController
    {
        public static void ResetApplicationState(
            PlotBindings plotBindings,
            Dictionary<PlotModel, List<CheckpointEntry>> multiGraphCheckpoints,
            ref AppFlags appFlags,
            ref PlotModel overlayModel,
            WpfSeries.PlotView overlayPlotView,
            Panel overlayPanel,
            Panel graphPanel,
            Grid dataItemTable,
            UIModel ui,
            out LineAnnotation playbackMarker,
            out PlaybackController playbackController,
            SelectionChangedEventHandler graphModeChangedHandler,
            List<MarkerBinding> markerBindings,
            Action<double> updateCallback,
            Action onStopCallback)
        {
            plotBindings.MultiGraphMarkers.Clear();
            plotBindings.MultiGraphMarkerToggles.Clear();
            plotBindings.PlotMap.Clear();
            plotBindings.SeriesMap.Clear();

            multiGraphCheckpoints.Clear();

            appFlags.NextCheckpointLabel = 'A';
            appFlags.OverlayYAxisUnit = null;
            appFlags.UnitMismatchWarningShown = false;
            appFlags.IsOverlayMode = false;
            appFlags.IsPlaying = false;
            appFlags.FileTypeWarningShown = false;

            ui.TripLabel.Visibility = Visibility.Visible;
            ui.TriggerLabel.Visibility = Visibility.Visible;

            overlayModel = new PlotModel();

            overlayPlotView.Model = overlayModel;

            overlayModel.Annotations.Clear();
            overlayModel.Series.Clear();
            overlayModel.InvalidatePlot(false);

            graphPanel.Children.Clear();

            dataItemTable.Children.Clear();
            dataItemTable.RowDefinitions.Clear();

            ui.TimeSlider.Value = 0;
            ui.TimeSlider.IsEnabled = false;
            ui.StepBackButton.IsEnabled = false;
            ui.PlayPauseButton.IsEnabled = false;
            ui.StepForwardButton.IsEnabled = false;
            ui.DeleteCheckpointButton.IsEnabled = false;
            ui.PlayPauseButton.Content = AppConstants.PlaySymbol;
            ui.GraphModeSelector.SelectionChanged -= graphModeChangedHandler;
            ui.GraphModeSelector.SelectedIndex = 0;
            ui.GraphModeSelector.IsEnabled = false;
            ui.GraphModeSelector.SelectionChanged += graphModeChangedHandler;

            overlayPanel.Visibility = Visibility.Collapsed;

            graphPanel.Visibility = Visibility.Visible;

            playbackMarker = new LineAnnotation
            {
                Type = LineAnnotationType.Vertical,
                Color = AppConstants.PlaybackMarkerColor,
                LineStyle = LineStyle.Solid,
                StrokeThickness = AppConstants.CheckpointLineThickness
            };

            playbackController = new PlaybackController(
                ui.TimeSlider,
                ui.PlayPauseButton,
                markerBindings,
                updateCallback,
                onStopCallback
            );
        }
    }
}