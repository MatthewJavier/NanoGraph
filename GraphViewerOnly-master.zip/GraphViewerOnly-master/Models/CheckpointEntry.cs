﻿namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    public class CheckpointEntry
    {
        public bool IsOverlay { get; set; }
        public double Time { get; set; }
    }
}