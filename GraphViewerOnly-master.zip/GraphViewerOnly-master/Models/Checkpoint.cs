﻿using OxyPlot.Annotations;

namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    public class Checkpoint
    {
        /// <summary>
        /// Identifier for the checkpoint, e.g. "A", "B", etc.
        /// </summary>
        public string Label { get; set; } = string.Empty;

        /// <summary>
        /// The visual marker associated with the checkpoint.
        /// </summary>
        public LineAnnotation Marker { get; set; } = new();

        /// <summary>
        /// Time in seconds when the checkpoint is placed.
        /// </summary>
        public double Time { get; set; }
    }
}