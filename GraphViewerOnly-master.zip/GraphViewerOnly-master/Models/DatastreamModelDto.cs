﻿namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    public class DatastreamModelDto
    {
        public string Description { get; set; } = string.Empty;

        public string ParamUnit => ParamUnits.FirstOrDefault() ?? "";
        public List<string> ParamUnits { get; set; } = new();
        public List<string> ParamValues { get; set; } = new();
        public List<string> TimeSeries { get; set; } = new();
    }
}