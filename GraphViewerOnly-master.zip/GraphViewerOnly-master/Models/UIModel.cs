﻿using System.Windows.Controls;

namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    public class UIModel
    {
        public Button DeleteCheckpointButton { get; set; }
        public ComboBox GraphModeSelector { get; set; }
        public Button PlayPauseButton { get; set; }
        public Button ResetGraphPositionButton { get; set; }
        public Button StepBackButton { get; set; }
        public Button StepForwardButton { get; set; }
        public Slider TimeSlider { get; set; }
        public TextBlock TriggerLabel { get; set; }
        public TextBlock TripLabel { get; set; }
    }
}