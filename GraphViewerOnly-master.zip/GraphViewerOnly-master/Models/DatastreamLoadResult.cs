﻿namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    public class DatastreamLoadResult
    {
        public List<DatastreamItem> Items { get; set; } = new();
        public string Trigger { get; set; } = "不明";
        public string TripName { get; set; } = string.Empty;
    }
}