﻿using OxyPlot;
using OxyPlot.Annotations;
using System.Windows.Controls;

namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    public class MarkerBinding
    {
        public LineAnnotation Marker { get; set; } = null;
        public PlotModel Model { get; set; } = null;
        public CheckBox? Toggle { get; set; }
    }
}