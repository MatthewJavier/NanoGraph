﻿namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    public class AppFlags
    {
        public bool FileTypeWarningShown;
        public bool IsOverlayMode;
        public bool IsPlaying;
        public char NextCheckpointLabel;

        public string? OverlayYAxisUnit;

        public bool UnitMismatchWarningShown;
    }
}