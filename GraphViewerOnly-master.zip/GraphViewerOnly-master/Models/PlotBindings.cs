﻿using OxyPlot;
using OxyPlot.Annotations;
using System.Windows.Controls;

namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    public class PlotBindings
    {
        public Dictionary<PlotModel, LineAnnotation> MultiGraphMarkers { get; set; }
        public Dictionary<PlotModel, CheckBox> MultiGraphMarkerToggles { get; set; }
        public Dictionary<CheckBox, OxyPlot.Wpf.PlotView> PlotMap { get; set; }
        public Dictionary<string, OxyPlot.Series.StairStepSeries> SeriesMap { get; set; }
    }
}