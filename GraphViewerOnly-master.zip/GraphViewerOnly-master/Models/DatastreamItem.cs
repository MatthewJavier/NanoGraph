﻿namespace nanoBT_2nd_for_Windows_GraphViewer.Models
{
    /// <summary>
    /// グラフ表示用の共通アイテムを表すクラス。
    /// Datastream形式以外のデータも格納するが、影響範囲が大きいため名称は据え置き
    /// </summary>
    public class DatastreamItem
    {
        public string Description { get; set; } = string.Empty;
        public List<DatastreamPoint> Points { get; set; } = new();
        public string Unit { get; set; } = string.Empty;
    }

    /// <summary>
    /// グラフポイントを表すクラス。時間と値のペアで構成される。
    /// </summary>
    public class DatastreamPoint
    {
        public double Time { get; set; }
        public double Value { get; set; }
    }
}