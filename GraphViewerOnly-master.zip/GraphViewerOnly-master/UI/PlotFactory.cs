﻿using nanoBT_2nd_for_Windows_GraphViewer.Constants;
using nanoBT_2nd_for_Windows_GraphViewer.Models;
using OxyPlot;
using OxyPlot.Annotations;
using OxyPlot.Axes;
using OxyPlot.Series;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using CoreSeries = OxyPlot.Series;
using WpfSeries = OxyPlot.Wpf;

namespace nanoBT_2nd_for_Windows_GraphViewer.UI
{
    public static class PlotFactory
    {

        // ▼ 現在チェックされている数を保持
        private static int _checkedCount = 0;

        // ▼ 追加：EDRデータ判定フラグ
        public static bool IsEdrData = false;

        public static Grid CreateSynchronizedPlot(
            DatastreamItem item,
            int colorIndex,
            Action<PlotModel, LineAnnotation> registerMarker,
            Action<PlotModel, CheckBox> registerToggle,
            bool isOverlayMode = false)
        {
            // プロットモデル生成
            var model = new PlotModel { Title = item.Description };

            // プロット時間範囲を取得 
            var (plotMinTime, plotMaxTime) = GetTimeRange(item);

            // X軸生成 
            var xAxis = CreateTimeAxis(plotMinTime, plotMaxTime);

            // Y軸生成 
            var yAxis = CreateValueAxis(item.Unit);

            // 軸をモデルに追加 
            model.Axes.Add(xAxis);
            model.Axes.Add(yAxis);

            // 系列を追加 
            AddSeries(model, item, colorIndex);

            // 再生位置マーカー生成 
            var marker = new LineAnnotation
            {
                Type = LineAnnotationType.Vertical,
                Color = AppConstants.PlaybackMarkerColor,
                StrokeThickness = AppConstants.MarkerStrokeThickness,
                X = 0,
                LineStyle = LineStyle.Solid
            };

            // マーカーをモデルに追加 
            model.Annotations.Add(marker);

            // マーカー登録 
            registerMarker(model, marker);

            // レイアウト用コンテナ生成 
            var container = new Grid();

            // 行レイアウトを設定 
            container.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            container.RowDefinitions.Add(new RowDefinition { Height = new GridLength(180) });

            // PlotView生成 
            var plotView = CreatePlotView(model);

            // PlotViewの配置位置を設定 
            Grid.SetRow(plotView, 1);

            // コンテナにPlotView追加 
            container.Children.Add(plotView);

            // 操作UIを追加 
            AddPlaybackControls(container, model, xAxis, plotMinTime, plotMaxTime, registerToggle, isOverlayMode);

            // コンテナを返却 
            return container;
        }


        // プロット時間範囲を取得 
        private static (double min, double max) GetTimeRange(DatastreamItem item)
        {
            double plotMinTime = 0;
            double plotMaxTime = 170000;

            if (item.Points.Count >= 2)
            {
                plotMinTime = item.Points.Min(p => p.Time);
                plotMaxTime = item.Points.Max(p => p.Time);

                if (plotMaxTime - plotMinTime < 10)
                {
                    if (!PlotFactory.IsEdrData)
                    {
                        plotMaxTime = plotMinTime + 10;
                    }
                }
            }
            else if (item.Points.Count == 1)
            {
                if (!PlotFactory.IsEdrData)
                {
                    plotMinTime = item.Points[0].Time;
                    plotMaxTime = plotMinTime + 10;
                }
                else
                {
                    plotMinTime = item.Points[0].Time;
                    plotMaxTime = plotMinTime + 1.0; // EDRは1秒幅
                }
            }
            // データなしの場合はデフォルト値を使用 
            else
            {
                // 何もせず初期値を返す
            }

            return (plotMinTime, plotMaxTime);

        }

        // X軸を生成 
        public static LinearAxis CreateTimeAxis(double plotMinTime, double plotMaxTime)
        {
            var xAxis = new LinearAxis
            {
                Position = AxisPosition.Bottom,
                Title = AppConstants.TimeAxisTitle,
                Minimum = plotMinTime,
                Maximum = plotMaxTime,
                AbsoluteMinimum = plotMinTime,
                AbsoluteMaximum = plotMaxTime,
                IsZoomEnabled = false,
                IsPanEnabled = false,

                // グリッド線設定
                MajorGridlineStyle = LineStyle.Solid,
                MinorGridlineStyle = LineStyle.Dot,
                AxislineStyle = LineStyle.None,

            };

            // ▼ 初期表示用にrangeを算出
            double range = xAxis.Maximum - xAxis.Minimum;



            // ▼ 目盛りとフォーマットを設定（統一処理）
            ApplyTimeAxisStep(xAxis, range);

            // 作成した軸を返す 
            return xAxis;
        }

        /// <summary>
        /// 表示範囲（range）に応じて目盛り間隔と表示フォーマットを設定する
        /// </summary>
        /// <param name="axis">対象の時間軸</param>
        /// <param name="range">表示範囲（初期化時はMaximum-Minimum、ズーム時はActual範囲）</param>
        internal static void ApplyTimeAxisStep(LinearAxis axis, double range)
        {

            // 目標とする目盛り数（多すぎ防止）
            int maxTicks = 8;

            // 表示範囲から理想的な目盛り間隔を算出
            // ▼ μsの場合だけ秒に変換
            double targetStep = range / maxTicks;

            // 時間として扱いやすいステップ候補一覧
            double[] niceSteps = new double[]
            {
                0.001, 0.005, 0.01, 0.05,
                0.1, 0.5,
                1, 5, 10, 30,
                60, 300, 600, 1800,
                3600, 7200, 10800
            };

            // targetStep以上で最も近いステップを選択
            double step = niceSteps.Where(s => s >= targetStep).DefaultIfEmpty(niceSteps.Last()).First();

            // ▼ EDRはstepを1以下に制限
            if (IsEdrData)
            {
                step = Math.Min(step, 1.0);
            }

            // 主目盛りと補助目盛りを設定
            axis.MajorStep = step;

            // ▼ 小さいレンジは細かく、大きいレンジは粗く
            if (step <= 600) // 10分以下
            {
                axis.MinorStep = step / 5.0;
            }
            else
            {
                axis.MinorStep = step / 3.0;
            }

            // ▼ 表示フォーマット
            if (step < 10)
            {
                // ▼ stepに応じて桁数を変える
                axis.LabelFormatter = x =>
                {
                    if (step >= 1)
                        return $"{x:F0} sec";

                    if (step >= 0.1)
                        return $"{x:F1} sec";

                    if (step >= 0.01)
                        return $"{x:F2} sec";

                    return $"{x:F3} sec";
                };

            }
            else if (step < 600)
            {
                axis.LabelFormatter = x => TimeSpan.FromSeconds(x).ToString(@"mm\:ss");
            }
            else
            {
                axis.LabelFormatter = x => TimeSpan.FromSeconds(x).ToString(@"hh\:mm");
            }

        }


        /// <summary>
        /// X軸（時間）の表示範囲を更新する。
        /// </summary>
        /// <param name="model"></param>
        /// <summary>
        public static void UpdateTimeAxisRange(PlotModel model)
        {
            // 系列が存在するかどうか
            bool hasSeries = model.Series.Count > 0;

            // 時間の最小・最大を探索
            double minX = double.MaxValue;
            double maxX = double.MinValue;

            foreach (var series in model.Series.OfType<LineSeries>())
            {
                foreach (var p in series.Points)
                {
                    if (p.X < minX) minX = p.X;
                    if (p.X > maxX) maxX = p.X;
                }
            }

            // 有効な点がなければ何もしない
            if (minX == double.MaxValue)
                return;

            // 表示レンジが狭すぎる場合は最低幅を確保
            if (maxX - minX < 10 && !IsEdrData)
                maxX = minX + 10;

            // X軸に反映
            foreach (var axis in model.Axes.Where(a => a.Position == AxisPosition.Bottom))
            {
                axis.Minimum = minX;
                axis.Maximum = maxX;

                // ▼ 範囲
                double range = maxX - minX;

                // ▼ 余白（5%）
                double margin = range * 0.05;

                // ▼ パン・ズーム制限範囲を更新（余白付き）
                axis.AbsoluteMinimum = minX - margin;
                axis.AbsoluteMaximum = maxX + margin;

                // 系列があるときのみズーム・パンを有効化
                axis.IsZoomEnabled = hasSeries;
                axis.IsPanEnabled = hasSeries;

            }

        }

        // Y軸を生成 
        public static LinearAxis CreateValueAxis(string unit)
        {
            var yAxis = new LinearAxis
            {
                Position = AxisPosition.Left,
                Title = unit,
                IsZoomEnabled = false,
                IsPanEnabled = false,
            };

            // 作成した軸を返す 
            return yAxis;
        }


        // データ系列を生成してモデルに追加 
        private static void AddSeries(PlotModel model, DatastreamItem item, int colorIndex)
        {
            // ▼ EDR時は小数秒表示、それ以外は整数秒表示
            string trackerFormat = $"系列: {{0}}\n受信時刻: {{2:F3}} sec\n値: {{4:0.##}} {item.Unit}";

            // マルチグラフのシリーズ生成
            var line = new CoreSeries.StairStepSeries
            {
                Title = item.Description,
                Color = AppConstants.SeriesColorPalette[colorIndex % AppConstants.SeriesColorPalette.Length],
                StrokeThickness = 2.5,
                TrackerFormatString = trackerFormat
            };

            model.IsLegendVisible = false;

            // 描画点数の最大数を制限（間引き）
            int maxPoints = 1500;
            int count = item.Points.Count;
            int step = count > maxPoints ? count / maxPoints : 1;

            for (int i = 0; i < count; i += step)
            {
                var pt = item.Points[i];
                line.Points.Add(new DataPoint(pt.Time, pt.Value));
            }
            model.Series.Add(line);
        }


        // PlotViewを生成 
        private static WpfSeries.PlotView CreatePlotView(PlotModel model)
        {
            var plotView = new WpfSeries.PlotView
            {
                Margin = new Thickness(0, 6, 0, 5),
                Model = model,
                IsManipulationEnabled = true,
            };

            plotView.Controller = new PlotController();

            // Enable mouse drag and wheel zoom as usual:
            //plotView.Controller.UnbindAll();
            plotView.Controller.Bind(new OxyMouseDownGesture(OxyMouseButton.Left), PlotCommands.Track);
            plotView.Controller.Bind(new OxyMouseDownGesture(OxyMouseButton.Right), PlotCommands.PanAt);
            plotView.Controller.Bind(new OxyMouseWheelGesture(), PlotCommands.ZoomWheel);

            plotView.Model.Axes[0].IsZoomEnabled = true;
            plotView.Model.Axes[0].IsPanEnabled = true;

            // Touch: two‑finger pinch zoom + one‑finger pan
            plotView.ManipulationStarting += (s, e) =>
            {
                e.ManipulationContainer = plotView; // relative coordinates
                e.Mode = ManipulationModes.Translate | ManipulationModes.Scale; // pan + pinch
                e.Handled = true; // avoid bubbling to parent containers
            };

            plotView.ManipulationDelta += (s, e) =>
            {
                var modelLocal = model;
                var width = plotView.ActualWidth;
                if (width <= 0) return;

                var xa = modelLocal.Axes.OfType<LinearAxis>().FirstOrDefault(a => a.Position == AxisPosition.Bottom);
                if (xa is null) return;

                // Pan (one finger): horizontal translation
                double dx = e.DeltaManipulation.Translation.X;
                if (xa.IsPanEnabled && Math.Abs(dx) > double.Epsilon)
                {
                    double scale = (xa.ActualMaximum - xa.ActualMinimum) / width;
                    xa.Pan(-dx * scale);
                }

                // Pinch (two fingers): scale around the gesture origin
                // NOTE: WPF gives incremental scale since last event.
                var scaleDelta = e.DeltaManipulation.Scale.X; // X only (time axis)
                if (xa.IsZoomEnabled && Math.Abs(scaleDelta - 1.0) > 0.001)
                {
                    // Map touch point to data X for stable zoom focus
                    var origin = e.ManipulationOrigin;
                    double focusX = xa.InverseTransform(origin.X);

                    // Compute new range around focus
                    double currentRange = xa.ActualMaximum - xa.ActualMinimum;
                    if (currentRange > 0)
                    {
                        // Fingers apart -> scaleDelta > 1 -> zoom in (smaller range)
                        double newRange = currentRange / scaleDelta;

                        // Keep within absolute bounds
                        newRange = Math.Max(1e-6, Math.Min(newRange, xa.AbsoluteMaximum - xa.AbsoluteMinimum));

                        double newMin = focusX - newRange * 0.5;
                        double newMax = focusX + newRange * 0.5;

                        // Clamp to absolute bounds
                        if (newMin < xa.AbsoluteMinimum)
                        {
                            newMax += (xa.AbsoluteMinimum - newMin);
                            newMin = xa.AbsoluteMinimum;
                        }
                        if (newMax > xa.AbsoluteMaximum)
                        {
                            newMin -= (newMax - xa.AbsoluteMaximum);
                            newMax = xa.AbsoluteMaximum;
                        }

                        xa.Zoom(newMin, newMax);
                    }
                }
                modelLocal.InvalidatePlot(false);
                e.Handled = true;
            };
            // 作成したPlotViewを返す
            return plotView;
        }

        // 操作UI（チェックボックス＋スライダー）を追加 
        private static void AddPlaybackControls(
            Grid container,
            PlotModel model,
            LinearAxis xAxis,
            double plotMinTime,
            double plotMaxTime,
            Action<PlotModel, CheckBox> registerToggle,
            bool isOverlayMode)
        {

            // オーバーレイ時はUIを追加しない 
            if (isOverlayMode)
                return;

            // チェックボックスの説明文を追加
            var contentPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal
            };

            contentPanel.Children.Add(new TextBlock
            {
                Text = AppConstants.PlaySymbol,
                Margin = new Thickness(0, 0, 4, 0)
            });

            contentPanel.Children.Add(new TextBlock
            {
                Text = "再生位置ラインを表示",
                Foreground = Brushes.White,
                FontSize = 11
            });


            var checkbox = new CheckBox
            {
                Content = contentPanel,
                Margin = new Thickness(4),
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                IsChecked = false,

                // 再生位置ラインはデフォルト表示
                //IsChecked = true,
                // チェックボックスを非表示に変更
                // Visibility = Visibility.Collapsed
            };

            var slider = new Slider
            {
                Minimum = 0,
                Maximum = 170000,
                SmallChange = 1000,
                LargeChange = 10000,
                Visibility = Visibility.Collapsed,
                Margin = new Thickness(8, 0, 8, 8),
            };

            bool isUserSliding = false;

            slider.PreviewMouseDown += (s, e) => isUserSliding = true;
            slider.PreviewMouseUp += (s, e) => isUserSliding = false;

            void SyncSliderToZoom()
            {
                if (isUserSliding) return;

                double visibleRange = xAxis.ActualMaximum - xAxis.ActualMinimum;

                if (visibleRange <= 0) return;

                slider.ValueChanged -= SliderOnValueChanged;

                slider.Minimum = plotMinTime;
                slider.Maximum = plotMaxTime - visibleRange;
                slider.Value = Math.Clamp(xAxis.ActualMinimum, slider.Minimum, slider.Maximum);

                slider.LargeChange = visibleRange / 2;
                slider.SmallChange = visibleRange / 10;

                slider.ValueChanged += SliderOnValueChanged;
            }

            // ▼ スライダー操作に応じてX軸の表示範囲を更新し、グラフを再描画する
            void SliderOnValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
            {
                // 現在表示されている範囲（時間幅）を取得
                double visibleRange = xAxis.ActualMaximum - xAxis.ActualMinimum;

                // 表示範囲が不正な場合は処理しない
                if (visibleRange <= 0) return;

                // ▼ スライダーの値を範囲内に制限して新しい最小値を決定
                double newMin = Math.Clamp(slider.Value, plotMinTime, plotMaxTime - visibleRange);

                // ▼ 表示幅を維持したまま最大値を決定
                double newMax = newMin + visibleRange;

                // ▼ 軸の表示範囲を更新（スクロール）
                xAxis.Zoom(newMin, newMax);

                // ▼ 更新結果を画面に反映するため再描画
                model.InvalidatePlot(false);
            }

            // Only resync on axis changes (avoid per-frame Updated)
            xAxis.AxisChanged += (s, e) =>
                {
                    if (slider.Visibility == Visibility.Visible)
                        SyncSliderToZoom();
                };

            slider.ValueChanged += SliderOnValueChanged;


            checkbox.PreviewMouseLeftButtonDown += (s, e) =>
            {

                // ▼ 同時表示数を制限（最大5個）
                int maxVisible = AppConstants.MaxMultiGraphMarkers;

                if (_checkedCount >= maxVisible)
                {
                    MessageBox.Show($"同時に表示できるのは{maxVisible}個までです。");

                    e.Handled = true; // ← ここでブロック（重要）
                }
            };

            checkbox.Checked += (s, e) =>
                {
                    // ▼ チェックされた数をカウント
                    _checkedCount++;

                    SetZoomEnabled(model, false);
                    // ズーム制限によりタイムスライダー不要（非表示）
                    //slider.Visibility = Visibility.Visible;
                    SyncSliderToZoom();
                };

            checkbox.Unchecked += (s, e) =>
            {
                // ▼ チェックが外されたらカウントを減らす
                _checkedCount--;

                SetZoomEnabled(model, false);
                //slider.Visibility = Visibility.Collapsed;
            };

            registerToggle(model, checkbox);

            container.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            container.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            Grid.SetRow(checkbox, 0);
            Grid.SetRow(slider, 2);

            container.Children.Add(checkbox);
            container.Children.Add(slider);
        }

        // ▼ VisualTreeから全CheckBoxを取得する
        private static IEnumerable<CheckBox> FindAllCheckBoxes(DependencyObject parent)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is CheckBox cb)
                    yield return cb;

                foreach (var descendant in FindAllCheckBoxes(child))
                    yield return descendant;
            }
        }


        // ズームとパンの有効/無効を切り替え
        public static void SetZoomEnabled(PlotModel model, bool enabled)
        {
            foreach (var axis in model.Axes)
            {
                axis.IsZoomEnabled = enabled;
                axis.IsPanEnabled = enabled;
            }
        }
    }
}