﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Input;
using nanoBT_2nd_for_Windows_GraphViewer.Models;

namespace nanoBT_2nd_for_Windows_GraphViewer.UI
{
    internal class GraphPanelManager
    {

        // 固定枠に移動した DatastreamItem を Undo 順で管理するスタック
        private static readonly Stack<DatastreamItem> _pinnedStack = new();


        public static void Populate(
            Grid dataItemTable,
            Grid fixedAreaGrid,
            StackPanel graphPanel,
            ComboBox graphModeSelector,
            Button playPauseButton,
            Button RestPlaybackButton,
            Button stepBackButton,
            Button stepForwardButton,
            Button deleteCheckpointButton,
            Button resetCheckpointButton,
            Slider timeSlider,
            List<DatastreamItem> items,
            Dictionary<CheckBox, OxyPlot.Wpf.PlotView> plotMap,
            System.Func<DatastreamItem, Grid> createPlotView,
            System.Action<CheckBox, RoutedEventHandler> bindCheckboxHandler,
            bool isOverlayMode = false)
        {
            dataItemTable.RowDefinitions.Clear();
            dataItemTable.Children.Clear();

            graphPanel.Children.Clear();

            plotMap.Clear();

            // データモニタの見出し行挿入
            AddDataTableHeader(fixedAreaGrid);

            for (int i = 0; i < items.Count; i++)
                // データモニタ挿入
                AddDataTableRow(dataItemTable, items[i], i + 1);

            foreach (var item in items)
            {
                CheckBox? checkBox = null;

                if (!isOverlayMode)
                {
                    // チェックボックスの説明を追加
                    var contentPanel = new StackPanel
                    {
                        Orientation = Orientation.Horizontal
                    };

                    contentPanel.Children.Add(new TextBlock
                    {
                        Text = $"{item.Description} [{item.Unit}]",
                        Margin = new Thickness(0, 0, 8, 0)
                    });

                    contentPanel.Children.Add(new TextBlock
                    {
                        Text = "（再生位置ライン）",
                        Foreground = Brushes.Gray,
                        FontSize = 11
                    });

                    checkBox = new CheckBox
                    {
                        Content = contentPanel,
                        IsChecked = true,
                        Tag = item,
                        Margin = new Thickness(4)
                    };

                    bindCheckboxHandler(checkBox, SignalCheckbox_Toggled);
                }

                var container = createPlotView(item);

                graphPanel.Children.Add(container);

                if (checkBox != null)
                {
                    var plotView = container.Children.OfType<OxyPlot.Wpf.PlotView>().FirstOrDefault();

                    if (plotView != null)
                        plotMap[checkBox] = plotView;
                }
            }

            if (items.Any() && items.All(i => i.Points.Count > 0))
            {
                var minTime = items.Min(i => i.Points.Min(p => p.Time));
                var maxTime = items.Max(i => i.Points.Max(p => p.Time));

                timeSlider.Minimum = minTime;
                timeSlider.Maximum = maxTime;
                timeSlider.Value = minTime;
            }

            graphModeSelector.IsEnabled = true;

            // デフォルト表示を重ねグラフに変更
            graphModeSelector.SelectedIndex = 1;

            playPauseButton.IsEnabled = true;

            RestPlaybackButton.IsEnabled = true;

            stepBackButton.IsEnabled = true;

            stepForwardButton.IsEnabled = true;

            timeSlider.IsEnabled = true;

            deleteCheckpointButton.IsEnabled = true;

            resetCheckpointButton.IsEnabled = true;
        }

        /// <summary>
        /// データモニタの見出し行
        /// </summary>
        /// <param name="dataItemTable"></param>
        private static void AddDataTableHeader(Grid dataItemTable)
        {
            dataItemTable.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            dataItemTable.Children.Add(CreateCell("項目", Brushes.LightGray, Brushes.Black, 0, 0));
            dataItemTable.Children.Add(CreateCell("値", Brushes.LightGray, Brushes.Black, 0, 1));
            dataItemTable.Children.Add(CreateCell("単位", Brushes.LightGray, Brushes.Black, 0, 2));
        }

        private static void AddDataTableRow(Grid dataItemTable, DatastreamItem item, int row)
        {
            dataItemTable.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var background = (row % 2 == 0) ? Brushes.White : Brushes.WhiteSmoke;
            var value = item.Points.LastOrDefault()?.Value.ToString("0.##") ?? "-";
            var rowGrid = new Grid
            {
                Background = background
            };

            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2.5, GridUnitType.Star) });
            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.5, GridUnitType.Star) });
            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.5, GridUnitType.Star) });


            // 行全体のデフォルト背景
            rowGrid.Children.Add(CreateGridElement(CreateText(item.Description, background, Brushes.Black), 0, 0));
            rowGrid.Children.Add(CreateGridElement(CreateText(value, background, Brushes.Black), 0, 1));
            rowGrid.Children.Add(CreateGridElement(CreateText(item.Unit, background, Brushes.Black), 0, 2));

            var wrapper = new Border
            {
                Tag = item,
                Child = rowGrid,
                Padding = new Thickness(2),
                Margin = new Thickness(1),
                BorderBrush = Brushes.DarkGray,
                BorderThickness = new Thickness(0.5),
                CornerRadius = new CornerRadius(3)
            };

            wrapper.MouseMove += (s, e) =>
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                    DragDrop.DoDragDrop(wrapper, new DataObject("DatastreamItem", item), DragDropEffects.Copy);
            };

            wrapper.MouseLeftButtonDown += (s, e) =>
            {
                if (e.ClickCount > 1)
                    e.Handled = true; // Suppress double-click
                else
                    e.Handled = true; // Also suppress single-click bubbling
            };

            wrapper.MouseLeftButtonUp += (s, e) => e.Handled = true;

            int newRow = dataItemTable.RowDefinitions.Count - 1;
            Grid.SetRow(wrapper, newRow);
            Grid.SetColumnSpan(wrapper, 3);

            dataItemTable.Children.Add(wrapper);
        }

        private static UIElement CreateCell(string text, Brush background, Brush foreground, int row, int col)
        {
            return CreateGridElement(new Border
            {
                BorderBrush = Brushes.Gray,
                BorderThickness = new Thickness(0.5),
                Background = background,
                Padding = new Thickness(4),
                Child = new TextBlock
                {
                    Text = text,
                    Foreground = foreground,
                    FontSize = 14,
                    TextAlignment = TextAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Center,
                    TextWrapping = TextWrapping.Wrap
                }
            }, row, col);
        }

        private static UIElement CreateGridElement(UIElement el, int row, int col)
        {
            Grid.SetRow(el, row);
            Grid.SetColumn(el, col);

            return el;
        }

        private static UIElement CreateText(string text, Brush background, Brush foreground)
        {
            return new Border
            {
                BorderBrush = Brushes.Gray,
                BorderThickness = new Thickness(0.5),
                Background = Brushes.Transparent,
                Padding = new Thickness(6),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch,
                Child = new TextBlock
                {
                    Text = text,
                    Foreground = foreground,
                    FontSize = 14,
                    TextWrapping = TextWrapping.Wrap,
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Left
                }
            };
        }

        private static void SignalCheckbox_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox cb)
                cb.Visibility = cb.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
        }

        /// <summary>
        /// ドロップ移動用：指定された DatastreamItem の表行を検索
        /// </summary>
        /// <param name="table"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        private static Border? FindRow(Grid table, DatastreamItem item)
        {
            return table.Children
                .OfType<Border>()
                .FirstOrDefault(b => ReferenceEquals(b.Tag, item));
        }

        /// <summary>
        /// DataItemTable から指定された DatastreamItem の行を取り出し、固定枠へ移動する
        /// 固定枠にコピーして一覧のデータは非表示に変更
        /// </summary>
        public static void MoveRowToFixedArea(
            Grid dataItemTable,
            Grid fixedAreaGrid,
            DatastreamItem item)
        {
            // 対象行を DataItemTable から検索
            var row = FindRow(dataItemTable, item);
            if (row == null)
                return;

            // ===== 一覧側は削除せず、非表示にする =====
            row.Visibility = Visibility.Collapsed;

            // ===== 固定枠にはコピー行を追加 =====
            // ※ row を直接使わない
            var copiedRow = CreateFixedAreaRow(item);

            // --- FixedAreaGrid 側に追加 ---
            int newRowIndex = fixedAreaGrid.RowDefinitions.Count;

            fixedAreaGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            Grid.SetRow(copiedRow, newRowIndex);
            Grid.SetColumnSpan(copiedRow, 3);

            fixedAreaGrid.Children.Add(copiedRow);
        }

        /// <summary>
        /// FixedArea 用の表示行を作成する
        /// （一覧と同じ構造・フォント・値表示）
        /// </summary>
        private static Border CreateFixedAreaRow(DatastreamItem item)
        {
            // ===== 一覧と同じ値生成ロジック =====
            var value = item.Points.LastOrDefault()?.Value.ToString("0.##") ?? "-";
            var background = new SolidColorBrush(Color.FromRgb(170, 215, 255)); // 固定枠用

            // ===== 行Grid（一覧と同構造）=====
            var rowGrid = new Grid
            {
                Background = background
            };

            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2.5, GridUnitType.Star) });
            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.5, GridUnitType.Star) });
            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.5, GridUnitType.Star) });

            // ===== 各セル（CreateText / CreateGridElement を流用）=====
            rowGrid.Children.Add(
                CreateGridElement(
                    CreateText(item.Description, background, Brushes.Black),
                    0, 0));

            rowGrid.Children.Add(
                CreateGridElement(
                    CreateText(value, background, Brushes.Black),
                    0, 1));

            rowGrid.Children.Add(
                CreateGridElement(
                    CreateText(item.Unit, background, Brushes.Black),
                    0, 2));

            // ===== Border でラップ（一覧と同じ）=====
            return new Border
            {
                Tag = item, // Undo 用
                Child = rowGrid,
                Padding = new Thickness(2),
                Margin = new Thickness(1),
                BorderBrush = Brushes.DarkGray,
                BorderThickness = new Thickness(0.5),
                CornerRadius = new CornerRadius(3)
            };
        }

        /// <summary>
        /// Grid 内の行を上から順に並べ直す
        /// </summary>
        private static void NormalizeGridRows(Grid grid, int startRow)
        {
            grid.RowDefinitions.Clear();

            var rows = grid.Children
                .OfType<Border>()
                .OrderBy(b => Grid.GetRow(b))
                .ToList();

            for (int i = 0; i < rows.Count; i++)
            {
                grid.RowDefinitions.Add(
                    new RowDefinition { Height = GridLength.Auto });

                Grid.SetRow(rows[i], startRow + i);
                if(i > 50)
                {
                    var temp = i;
                }
            }
        }

        /// <summary>
        /// 指定された DatastreamItem の行を固定枠から一覧へ戻す
        /// （固定枠のコピーを削除し、一覧側を再表示する）
        /// </summary>
        public static void UndoPinnedRow(
            Grid dataItemTable,
            Grid fixedAreaGrid,
            DatastreamItem item)
        {
            // --- 固定枠側：コピー行を探して削除 ---
            var copiedRow = fixedAreaGrid.Children
                .OfType<Border>()
                .FirstOrDefault(b => ReferenceEquals(b.Tag, item));

            if (copiedRow != null)
            {
                fixedAreaGrid.Children.Remove(copiedRow);
            }

            // --- 一覧側：元の行を再表示 ---
            var originalRow = FindRow(dataItemTable, item);
            if (originalRow != null)
            {
                originalRow.Visibility = Visibility.Visible;
            }
        }
    }
}