﻿using nanoBT_2nd_for_Windows_GraphViewer.Constants;
using OxyPlot;
using OxyPlot.Annotations;
using OxyPlot.Axes;
using OxyPlot.Legends;
using OxyPlot.Series;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Media3D;
using WpfPlotView = OxyPlot.Wpf.PlotView;

namespace nanoBT_2nd_for_Windows_GraphViewer.UI
{
    public static class OverlayPlotManager
    {

        // ▼ ピンチ開始時の固定中心（ズームの基準点）
        private static double? _pinchCenterX;

        // ▼ ピンチ中フラグ（毎フレーム中心がズレるのを防ぐ）
        private static bool _isPinching;

        public static void Setup(
            PlotModel overlayModel,
            WpfPlotView overlayPlotView,
            Panel overlayPanel,
            Panel graphPanel,
            LineAnnotation playbackMarker,
            DragEventHandler dropHandler)
        {

            // モデル初期化
            InitializeModel(overlayModel);

            // 初期表示用の時間範囲
            double plotMinTime = 0;
            double plotMaxTime = 200;

            if (PlotFactory.IsEdrData)
            {
                plotMinTime = -5;
                plotMaxTime = 5;
            }



            // 軸を生成
            var xAxis = PlotFactory.CreateTimeAxis(plotMinTime, plotMaxTime);
            var leftAxis = CreateLeftAxis();
            var rightAxis = CreateRightAxis();

            // 軸をモデルに追加
            overlayModel.Axes.Add(xAxis);
            overlayModel.Axes.Add(leftAxis);
            overlayModel.Axes.Add(rightAxis);

            // 凡例を設定
            SetupLegend(overlayModel);

            // 再生マーカー設定
            SetupPlaybackMarker(overlayModel, playbackMarker);

            // PlotView設定
            SetupPlotView(overlayPlotView, overlayModel, dropHandler);

            // スライダーUI設定
            //SetupSlider(overlayModel, overlayPanel, graphPanel, xAxis, plotMinTime, plotMaxTime);

        }


        // モデルを初期状態にリセット
        private static void InitializeModel(PlotModel overlayModel)
        {
            overlayModel.Annotations.Clear();
            overlayModel.Series.Clear();
            overlayModel.Axes.Clear();
            overlayModel.Legends.Clear();
            overlayModel.PlotType = PlotType.XY;
            overlayModel.Background = OxyColors.White;

        }

        // 左Y軸を生成
        private static LinearAxis CreateLeftAxis()
        {
            // 左Y軸を生成（PlotFactoryの共通定義を使用）
            var leftAxis = PlotFactory.CreateValueAxis(String.Empty);

            // Overlay用の見た目・挙動を上書き
            leftAxis.Key = "YL";
            leftAxis.TitleColor = AppConstants.PlaybackMarkerColor;
            leftAxis.TextColor = AppConstants.PlaybackMarkerColor;
            leftAxis.MajorGridlineStyle = LineStyle.Solid;
            leftAxis.MinorGridlineStyle = LineStyle.Dot;
            leftAxis.AxislineStyle = LineStyle.None;
            leftAxis.IsZoomEnabled = false;
            leftAxis.IsPanEnabled = false;
            leftAxis.Tag = null;

            // 作成した軸を返す
            return leftAxis;

        }


        // 右Y軸を生成
        private static LinearAxis CreateRightAxis()
        {
            // 右Y軸を生成
            var rightAxis = PlotFactory.CreateValueAxis(String.Empty);

            // Overlay用設定
            rightAxis.Position = AxisPosition.Right;
            rightAxis.Key = "YR";
            rightAxis.TitleColor = AppConstants.PlaybackMarkerColor;
            rightAxis.TextColor = AppConstants.PlaybackMarkerColor;
            rightAxis.MajorGridlineStyle = LineStyle.None;
            rightAxis.MinorGridlineStyle = LineStyle.None;
            rightAxis.AxislineStyle = LineStyle.None;
            rightAxis.IsZoomEnabled = false;
            rightAxis.IsPanEnabled = false;
            rightAxis.IsAxisVisible = false;
            rightAxis.Tag = null;

            // 作成した軸を返す
            return rightAxis;

        }


        // 凡例を設定してモデルに追加
        private static void SetupLegend(PlotModel overlayModel)
        {
            // グラフの凡例表示を非表示
            overlayModel.IsLegendVisible = false;

            // 凡例オブジェクトを生成
            var legend = new Legend
            {
                LegendPlacement = AppConstants.legendPlacement,
                LegendPosition = AppConstants.legendPosition,
                LegendOrientation = AppConstants.legendOrientation,
                LegendBorderThickness = AppConstants.LegendBorderThickness,
                LegendBorder = AppConstants.legendBorder,
                LegendBackground = AppConstants.legendBackground
            };

            // 凡例をモデルに追加
            overlayModel.Legends.Add(legend);

        }


        // 再生位置マーカーを初期化してモデルに登録
        private static void SetupPlaybackMarker(PlotModel overlayModel, LineAnnotation playbackMarker)
        {
            // マーカーが存在しない場合は何もしない
            if (playbackMarker == null)
            {
                return;
            }

            // 縦線として表示するように設定
            playbackMarker.Type = LineAnnotationType.Vertical;

            // マーカーの色を設定
            playbackMarker.Color = AppConstants.PlaybackMarkerColor;

            // 線の太さを設定
            playbackMarker.StrokeThickness = AppConstants.MarkerStrokeThickness;

            // 線スタイルを設定
            playbackMarker.LineStyle = LineStyle.Solid;

            // 初期位置を0に設定
            playbackMarker.X = 0;

            // 既存登録を解除してから再登録
            overlayModel.Annotations.Remove(playbackMarker);
            overlayModel.Annotations.Add(playbackMarker);

        }


        // PlotViewの設定と操作イベントを初期化
        private static void SetupPlotView(
            WpfPlotView overlayPlotView,
            PlotModel overlayModel,
            DragEventHandler dropHandler)
        {
            // モデルを設定
            overlayPlotView.Model = overlayModel;

            // ドロップ操作を有効化
            overlayPlotView.AllowDrop = true;

            // タッチ操作を有効化
            overlayPlotView.IsManipulationEnabled = true;

            // ドロップイベントを再登録
            overlayPlotView.Drop -= dropHandler;
            overlayPlotView.Drop += dropHandler;

            // 長押しによる右クリック化を無効化
            Stylus.SetIsPressAndHoldEnabled(overlayPlotView, false);

            // コントローラを初期化
            overlayPlotView.Controller = new PlotController();

            // マウス操作（追跡・パン・ズーム）を設定
            overlayPlotView.Controller.Bind(new OxyMouseDownGesture(OxyMouseButton.Left), PlotCommands.Track);
            overlayPlotView.Controller.Bind(new OxyMouseDownGesture(OxyMouseButton.Right), PlotCommands.PanAt);

            // ▼ ホイールでX軸のみズーム
            overlayPlotView.Controller.Bind(
                new OxyMouseWheelGesture(),
                new DelegatePlotCommand<OxyMouseWheelEventArgs>(OnMouseWheelZoomXOnly));

            // タッチ操作イベントを設定
            overlayPlotView.ManipulationStarting -= OnManipulationStarting;
            overlayPlotView.ManipulationStarting += OnManipulationStarting;

            overlayPlotView.ManipulationDelta -= OnManipulationDelta;
            overlayPlotView.ManipulationDelta += OnManipulationDelta;

            // ▼ ピンチ終了時の状態リセット
            overlayPlotView.ManipulationCompleted -= OnManipulationCompleted;
            overlayPlotView.ManipulationCompleted += OnManipulationCompleted;

            // X軸のズーム・パンを有効化
            overlayPlotView.Model.Axes[0].IsZoomEnabled = true;
            overlayPlotView.Model.Axes[0].IsPanEnabled = true;

            // ▼ Ctrl付きマウス操作を無効化（多重登録防止）
            overlayPlotView.PreviewMouseDown -= SuppressCtrlMouseDown;
            overlayPlotView.PreviewMouseDown += SuppressCtrlMouseDown;

            overlayPlotView.PreviewMouseMove -= SuppressCtrlMouse;
            overlayPlotView.PreviewMouseMove += SuppressCtrlMouse;

            overlayPlotView.PreviewMouseUp -= SuppressCtrlMouse;
            overlayPlotView.PreviewMouseUp += SuppressCtrlMouse;

        }

        // ▼ Ctrl付き操作を無効化
        private static void SuppressCtrlMouse(object? sender, MouseEventArgs e)
        {
            if ((Keyboard.Modifiers & ModifierKeys.Control) != 0)
                e.Handled = true;
        }

        private static void SuppressCtrlMouseDown(object? sender, MouseButtonEventArgs e)
        {
            if ((Keyboard.Modifiers & ModifierKeys.Control) != 0)
                e.Handled = true;
        }


        // 再生スライダーと連動処理を設定
        private static void SetupSlider(
            PlotModel overlayModel,
            Panel overlayPanel,
            Panel graphPanel,
            LinearAxis xAxis,
            double plotMinTime,
            double plotMaxTime)
        {
            // スライダーを生成
            var slider = new Slider
            {
                Minimum = 0,
                Maximum = 170000,
                SmallChange = 1000,
                LargeChange = 10000,
                Visibility = Visibility.Collapsed,
                Margin = new Thickness(8, 0, 8, 8),
            };

            // スライダー操作中かどうかのフラグ
            bool isUserSliding = false;

            // 初期表示を有効化
            slider.Visibility = Visibility.Visible;

            // スライダー操作開始・終了を検知
            slider.PreviewMouseDown += (s, e) => isUserSliding = true;
            slider.PreviewMouseUp += (s, e) => isUserSliding = false;

            // スライダー位置をズーム範囲に同期
            void SyncSliderToZoom()
            {
                if (isUserSliding) return;

                double visibleRange = xAxis.ActualMaximum - xAxis.ActualMinimum;

                if (visibleRange <= 0) return;

                slider.ValueChanged -= SliderOnValueChanged;

                // 表示範囲に合わせてスライダー範囲を更新
                slider.Minimum = plotMinTime;
                slider.Maximum = plotMaxTime - visibleRange;
                slider.Value = Math.Clamp(xAxis.ActualMinimum, slider.Minimum, slider.Maximum);

                // 操作ステップを更新
                slider.LargeChange = visibleRange / 2;
                slider.SmallChange = visibleRange / 10;

                slider.ValueChanged += SliderOnValueChanged;
            }

            // スライダー操作でX軸を移動
            void SliderOnValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
            {
                double visibleRange = xAxis.ActualMaximum - xAxis.ActualMinimum;

                if (visibleRange <= 0) return;

                double newMin = Math.Clamp(slider.Value, plotMinTime, plotMaxTime - visibleRange);
                double newMax = newMin + visibleRange;

                // 軸をズーム（移動）
                xAxis.Zoom(newMin, newMax);

                // スライダー変更イベント登録
                overlayModel.InvalidatePlot(false);
            }

            // 軸変更時にスライダーを再同期
            xAxis.AxisChanged += (s, e) => SyncSliderToZoom();

            // スライダー変更イベント登録
            slider.ValueChanged += SliderOnValueChanged;

            // 既存スライダーを削除してから追加
            if (overlayPanel is Panel panel)
            {
                var existingSliders = overlayPanel.Children.OfType<Slider>().ToList();

                foreach (var s in existingSliders)
                    overlayPanel.Children.Remove(s);

                panel.Children.Add(slider);
            }

            // オーバーレイパネルを表示
            overlayPanel.Visibility = Visibility.Visible;

            // 元グラフを非表示
            graphPanel.Visibility = Visibility.Collapsed;

        }


        // 再生位置マーカーが未追加の場合のみ安全に追加して描画する
        public static void EnsurePlaybackMarker(PlotModel model, LineAnnotation marker)
        {
            // マーカーが null の場合は処理しない
            if (marker == null) return;

            // まだグラフに追加されていない場合のみ追加する
            if (!model.Annotations.Contains(marker))
            {
                model.Annotations.Add(marker);
            }
        }


        /// <summary>
        /// 軸の表示範囲と状態を更新し、グラフを再描画する
        /// </summary>
        /// <param name="model"></param>
        public static void UpdateZoomPanState(PlotModel model)
        {

            // null ガード
            if (model == null)
                return;

            // 時間軸（X軸）の更新
            PlotFactory.UpdateTimeAxisRange(model);

            // 第一単位（左Y軸）の更新
            UpdateLeftValueAxis(model);

            // 第二単位（右Y軸）の更新
            UpdateRightValueAxis(model);

        }


        /// <summary>
        /// 左Y軸（第一単位）のスケールを計算して反映する。
        /// ※桁数が著しく異なると中央よりになる（要検討）
        /// </summary>
        /// <param name="model"></param>
        private static void UpdateLeftValueAxis(PlotModel model)
        {

            // 左Y軸を取得
            var axis = model.Axes.OfType<LinearAxis>().First(a => a.Key == "YL");

            // 左Y軸に割り当てられた系列のポイントを収集
            var points = model.Series
                .OfType<LineSeries>()
                .Where(s => s.YAxisKey == "YL")
                .SelectMany(s => s.Points)
                .ToList();

            // 系列が 0 本のときは、軸を「自動状態」に戻す
            if (!points.Any())
            {
                // 目盛を自動に戻す
                axis.MajorStep = double.NaN;
                axis.MinorStep = double.NaN;

                // ★ 表示範囲も必ず自動に戻す（これが重要）
                axis.Minimum = double.NaN;
                axis.Maximum = double.NaN;

                axis.IsZoomEnabled = true;
                axis.IsPanEnabled = false;

                return;
            }

            // データが無い場合は何もしない
            if (!TryGetAxisRange(points, out var min, out var max, out var range))
                return;

            // ▼ 単一点のときは擬似レンジを作る
            if (points.Count == 1)
            {
                range = Math.Max(Math.Abs(max) * 0.1, 1.0); // 最低1保証
            }

            // Undo 等に備え、スケール固定情報を毎回破棄
            axis.Tag = null;

            // 系列1本目は中央寄せ、それ以外は通常マージン
            double margin = points.Count == 1
                ? range * 0.5
                : range * 0.1;

            // 有効数字を考慮したステップを計算
            double span = (max + margin) - (min - margin);

            double step = span <= 15
                ? 1.0
                : RoundTo1_2_5(span / 6.0);

            // 最小・最大をステップ単位で丸めて設定
            axis.Minimum = Math.Floor((min - margin) / step) * step;
            axis.Maximum = Math.Ceiling((max + margin) / step) * step;

            // 目盛設定
            axis.MajorStep = step;
            axis.MinorStep = step / 5.0;

            // ラベルの間引きを抑制
            axis.IntervalLength = 10;

            axis.IsZoomEnabled = true;
            axis.IsPanEnabled = false;
        }

        /// <summary>
        /// 右Y軸（第二単位）のスケールを計算して反映する。
        /// </summary>
        /// <param name="model"></param>
        private static void UpdateRightValueAxis(PlotModel model)
        {
            // 左右のY軸を取得
            var leftAxis = model.Axes.OfType<LinearAxis>().First(a => a.Key == "YL");
            var rightAxis = model.Axes.OfType<LinearAxis>().First(a => a.Key == "YR");

            // 右Y軸に割り当てられた系列のポイントを収集
            var points = model.Series
                .OfType<LineSeries>()
                .Where(s => s.YAxisKey == "YR")
                .SelectMany(s => s.Points)
                .ToList();

            // 右軸の系列が無ければ軸を非表示
            if (!points.Any())
            {
                rightAxis.MajorStep = double.NaN;
                rightAxis.MinorStep = double.NaN;

                // ★ 範囲リセット
                rightAxis.Minimum = double.NaN;
                rightAxis.Maximum = double.NaN;

                rightAxis.IsAxisVisible = false;
                rightAxis.IsZoomEnabled = false;
                rightAxis.IsPanEnabled = false;

                return;
            }

            // データ範囲を取得
            if (!TryGetAxisRange(points, out var min, out var max, out var range))
                return;

            // ▼ 単一点のときは擬似レンジを作る
            if (points.Count == 1)
            {
                range = Math.Max(Math.Abs(max) * 0.1, 1.0); // 最低1保証
            }

            // Undo 等に備え、固定情報を破棄
            rightAxis.Tag = null;
            rightAxis.IsAxisVisible = true;

            // 下側は控えめ、上側は従来通りのマージン
            double lowerMargin = points.Count == 1 ? range * 0.5 : range * 0.05;
            double upperMargin = points.Count == 1 ? range * 0.5 : range * 0.1;

            // 有効数字を考慮したステップ
            double step = CalculateRoundStep(min, max);

            // 上側は必ず丸める（大きい方基準）
            double maxRounded = Math.Ceiling((max + upperMargin) / step) * step;

            // 下側は小数で 0 に引っ張られないように調整
            double minCandidate = min - lowerMargin;
            double minRounded = step > range
                ? minCandidate
                : Math.Floor(minCandidate / step) * step;

            // 軸範囲を設定
            rightAxis.Minimum = minRounded;
            rightAxis.Maximum = maxRounded;

            // 表示幅に応じた目盛調整
            double span = maxRounded - minRounded;
            double majorStep = span <= 15
                ? 1.0
                : RoundTo1_2_5(span / 6.0);

            rightAxis.MajorStep = majorStep;
            rightAxis.MinorStep = majorStep / 5.0;

            // ラベルの間引きを抑制
            rightAxis.IntervalLength = 10;

            rightAxis.IsZoomEnabled = true;
            rightAxis.IsPanEnabled = false;

        }

        /// <summary>
        /// Y値の最小・最大・レンジを安全に取得する。
        /// </summary>
        /// <param name="points"></param>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <param name="range"></param>
        /// <returns></returns>
        private static bool TryGetAxisRange(
            IEnumerable<DataPoint> points,
            out double min,
            out double max,
            out double range)
        {
            // 初期化
            min = max = range = 0;

            // null／空ガード
            if (points == null) return false;
            var list = points as IList<DataPoint> ?? points.ToList();
            if (list.Count == 0) return false;

            // 最小・最大
            min = list.Min(p => p.Y);
            max = list.Max(p => p.Y);

            // レンジ（ゼロ対策）
            range = max - min;
            if (range <= 0)
                range = Math.Abs(max) * 0.1 + 1.0;

            return true;
        }

        // ▼ タッチ操作（パン・ピンチ）に応じてX軸の表示範囲を更新し再描画する
        private static void OnManipulationDelta(object? sender, ManipulationDeltaEventArgs e)
        {
            // PlotView以外からの呼び出しは無視
            if (sender is not WpfPlotView pv) return;

            // モデルが存在しない場合は処理しない
            if (pv.Model is not PlotModel model) return;

            // 下側（時間軸）のLinearAxisを取得
            var xa = model.Axes.OfType<LinearAxis>().FirstOrDefault(a => a.Position == AxisPosition.Bottom);
            if (xa is null) return;

            // ▼ ピンチ判定（2本指が確定した瞬間）
            bool isPinchNow = Math.Abs(e.CumulativeManipulation.Scale.X - 1.0) > 0.01;

            // ▼ 初回の「ピンチ開始」でのみ中心を取得
            if (isPinchNow && !_pinchCenterX.HasValue)
            {
                _pinchCenterX = xa.InverseTransform(e.ManipulationOrigin.X);
            }

            // ▼ ズーム中心は常に固定値を使う
            double focusX = _pinchCenterX ?? xa.InverseTransform(e.ManipulationOrigin.X);

            // 描画領域の幅を取得（ピクセル）
            double width = pv.ActualWidth;
            if (width <= 0) return;

            // ▼ パン操作（1本指のスワイプで横移動）
            double dx = e.DeltaManipulation.Translation.X;
            // ▼ ピンチ中はパンしない（ズーム安定化）
            if (!isPinchNow && xa.IsPanEnabled && Math.Abs(dx) > double.Epsilon)
            {
                // ピクセル移動量 → データ座標への変換倍率
                double scale = (xa.ActualMaximum - xa.ActualMinimum) / width;

                // マウス移動量に応じて軸を平行移動
                xa.Pan(-dx * scale);
            }

            // ▼ ピンチ操作（2本指で拡大・縮小）
            double scaleDelta = e.DeltaManipulation.Scale.X; // 横方向のみ使用
            if (xa.IsZoomEnabled && Math.Abs(scaleDelta - 1.0) > 0.02)
            {

                // 現在の表示範囲を取得
                double currentRange = xa.ActualMaximum - xa.ActualMinimum;

                if (currentRange > 0)
                {
                    // スケールから新しい表示範囲を計算（大きい→縮小＝ズームイン）
                    // ▼ ズームの効きすぎを抑える
                    double zoomFactor = 1 + (scaleDelta - 1) * 0.5;
                    double newRange = currentRange / zoomFactor;                    // 無限に拡大しないよう下限を設定

                    // ▼ 全体範囲を取得
                    double fullRange = xa.AbsoluteMaximum - xa.AbsoluteMinimum;

                    // ▼ 最小ズーム幅（割合ベース）
                    double minRange = fullRange * AppConstants.MinZoomRatio;

                    // ▼ ズーム制限適用
                    newRange = Math.Max(newRange, minRange);

                    // ズーム中心を基準に表示範囲を再計算
                    double newMin = focusX - newRange * 0.5;
                    double newMax = focusX + newRange * 0.5;

                    // X軸の表示範囲を更新
                    xa.Zoom(newMin, newMax);

                    // ▼ ズーム後に目盛り更新
                    double range = xa.ActualMaximum - xa.ActualMinimum;
                    PlotFactory.ApplyTimeAxisStep(xa, range);
                }
            }

            // ▼ 操作結果を反映するため再描画
            model.InvalidatePlot(false);

            // イベント処理済みとして他へ伝播しない
            e.Handled = true;
        }

        // ▼ ピンチ終了時に状態リセット
        private static void OnManipulationCompleted(object? sender, ManipulationCompletedEventArgs e)
        {
            _isPinching = false;


            // ▼ 中心も必ずリセット
            _pinchCenterX = null;

        }

        // Static handlers so we can safely attach/detach across repeated Setup calls
        private static void OnManipulationStarting(object? sender, ManipulationStartingEventArgs e)
        {
            if (sender is not WpfPlotView pv) return;

            // ▼ ピンチ開始（まだ中心は取らない）
            _pinchCenterX = null;
            _isPinching = true;

            e.ManipulationContainer = pv; // relative coords
            e.Mode = ManipulationModes.Translate | ManipulationModes.Scale; // pan + pinch
            e.Handled = true; // avoid bubbling to parents which may capture
        }


        /// <summary>
        /// Y軸を区切りのいい境界に丸めるための step
        /// </summary>
        /// <param name="minValue"></param>
        /// <param name="maxValue"></param>
        /// <returns></returns>
        private static double CalculateRoundStep(double minValue, double maxValue)
        {
            double range = Math.Abs(maxValue - minValue);

            if (range <= 0)
                return Math.Max(Math.Abs(maxValue) * 0.1, 1.0);

            double rawStep = range / 6.0; // 目標：6分割

            double magnitude = Math.Pow(10, Math.Floor(Math.Log10(rawStep)));
            double normalized = rawStep / magnitude;

            double step;

            if (normalized < 1.5)
                step = 1 * magnitude;
            else if (normalized < 3)
                step = 2 * magnitude;
            else if (normalized < 7)
                step = 5 * magnitude;
            else
                step = 10 * magnitude;

            return step;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private static double RoundTo1_2_5(double value)
        {
            double power = Math.Pow(10, Math.Floor(Math.Log10(value)));
            double normalized = value / power;

            if (normalized < 1.5) return 1 * power;
            if (normalized < 3.0) return 2 * power;
            if (normalized < 7.0) return 5 * power;
            return 10 * power;
        }

        // ▼ ホイールでX軸のみズーム（ピンチと挙動統一）
        private static void OnMouseWheelZoomXOnly(IPlotView view, IController controller, OxyMouseWheelEventArgs args)
        {
            if (view.ActualModel?.DefaultXAxis is not LinearAxis xa)
                return;

            // ▼ 拡大率
            double factor = args.Delta > 0 ? 0.8 : 1.2;

            // ▼ 現在範囲
            double min = xa.ActualMinimum;
            double max = xa.ActualMaximum;

            // ▼ 範囲ゼロ防止
            if (Math.Abs(max - min) < 1e-9)
                return;

            // ▼ マウス位置
            double center = xa.InverseTransform(args.Position.X);

            // ▼ 新しい範囲
            double newRange = (max - min) * factor;

            // ▼ 全体範囲
            double fullRange = xa.AbsoluteMaximum - xa.AbsoluteMinimum;

            // ▼ 最小ズーム幅（割合）
            double minRange = fullRange * AppConstants.MinZoomRatio;

            // ▼ 制限
            newRange = Math.Max(newRange, minRange);

            // ▼ マウス位置の割合
            double ratio = (center - min) / (max - min);

            // ▼ 新しい範囲
            double newMin = center - newRange * ratio;
            double newMax = center + newRange * (1 - ratio);

            xa.Zoom(newMin, newMax);

            // ▼ ズーム後に目盛り・フォーマット更新
            // ▼ ズーム後に目盛り更新
            double range = xa.ActualMaximum - xa.ActualMinimum;
            PlotFactory.ApplyTimeAxisStep(xa, range);

            view.ActualModel.InvalidatePlot(false);
        }
    }
}