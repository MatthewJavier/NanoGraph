﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Windows.Input;

namespace nanoBT_2nd_for_Windows_GraphViewer.Helpers
{
    // 引数なしの処理を ICommand として扱うための簡易コマンド
    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool>? _canExecute;

        // 常に実行可能なコマンドを作成する
        public RelayCommand(Action execute)
            : this(execute, null)
        {
        }

        // 実行可能条件付きのコマンドを作成する
        public RelayCommand(Action execute, Func<bool>? canExecute)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        // 現在実行可能かどうかを判断する
        public bool CanExecute(object? parameter)
        {
            return _canExecute?.Invoke() ?? true;
        }

        // コマンド実行時の処理
        public void Execute(object? parameter)
        {
            _execute();
        }

        // 実行可否が変わったことを通知するイベント
        public event EventHandler? CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
}