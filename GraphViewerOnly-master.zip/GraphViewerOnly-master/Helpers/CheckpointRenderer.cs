﻿using nanoBT_2nd_for_Windows_GraphViewer.Constants;
using OxyPlot;
using OxyPlot.Annotations;
using OxyPlot.Axes;

namespace nanoBT_2nd_for_Windows_GraphViewer.Helpers
{
    public static class CheckpointRenderer
    {

        /// <summary>
        /// Adds a vertical line and triangle checkpoint marker to the specified plot model.
        /// </summary>
        public static void AddCheckpoint(double time, PlotModel model)
        {
            // チェックポイント1件を識別するための一意なID
            var checkpointId = Guid.NewGuid();


            // Line marker
            var line = new LineAnnotation
            {
                Type = LineAnnotationType.Vertical,
                Color = AppConstants.CheckpointLineColor,
                StrokeThickness = AppConstants.CheckpointLineThickness,
                LineStyle = LineStyle.Solid,
                X = time,
            };

            model.Annotations.Add(line);

            line.Tag = checkpointId;

            // Determine current top Y-axis position
            double yTop = model.Axes.FirstOrDefault(a => a.Position == AxisPosition.Left)?.ActualMaximum ?? 0;

            // チェックポイントの A/B ラベルを上端から1文字分下に表示
            var label = new TextAnnotation
            {
                // 仮ラベル（後で再採番される）
                Text = "?", // 再割り当て前のダミー

                TextHorizontalAlignment = HorizontalAlignment.Left,
                Offset = new ScreenVector(4, 4),
                TextVerticalAlignment = VerticalAlignment.Top,
                FontSize = 12,
                TextPosition = new DataPoint(time, yTop),
                Stroke = OxyColors.Transparent,
                TextColor = AppConstants.CheckpointTriangleFill
            };
            model.Annotations.Add(label);

            label.Tag = checkpointId;

            // チェックポイント位置を示す三角マーカーをA/Bラベルの下に表示
            var triangle = new TextAnnotation
            {
                Text = AppConstants.CheckpointSymbol,
                TextHorizontalAlignment = HorizontalAlignment.Center,
                Offset = new ScreenVector(0, 12),
                TextVerticalAlignment = VerticalAlignment.Top,
                FontSize = 16,
                TextPosition = new DataPoint(time, yTop),
                Stroke = OxyColors.Transparent,
                TextColor = AppConstants.CheckpointTriangleFill
            };

            model.Annotations.Add(triangle);

            triangle.Tag = checkpointId;

        }


        /// <summary>
        /// プロット上のすべてのチェックポイント関連アノテーションとマーカーを削除します。
        /// </summary>
        public static void ResetAllCheckpoints(PlotModel model)
        {

            // Tag が付いているチェックポイント関連 Annotation をすべて削除
            model.Annotations
                .Where(a => a.Tag is Guid)
                .ToList()
                .ForEach(a => model.Annotations.Remove(a));

        }

        // チェックポイントのTime順に A/B/C を再割り当てする
        public static void ReassignCheckpointLabels(PlotModel model)
        {
            // チェックポイント用 TextAnnotation を時間順に取得
            var labels = model.Annotations
                .OfType<TextAnnotation>()
                .Where(a =>
                    a.Tag is Guid &&
                    a.TextHorizontalAlignment == HorizontalAlignment.Left // ← ラベル専用
                )
                .OrderBy(a => a.TextPosition.X) // Time順
                .ToList();

            char label = 'A';
            foreach (var annotation in labels)
            {
                annotation.Text = label.ToString();
                label++;
            }
        }

    }
}