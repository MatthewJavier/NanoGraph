﻿using nanoBT_2nd_for_Windows_GraphViewer.Models;
using nanoBT_2nd_for_Windows_GraphViewer.Services;
using nanoBT_2nd_for_Windows_GraphViewer.UI;
using Newtonsoft.Json;
using System.IO;
using System.Windows;

namespace nanoBT_2nd_for_Windows_GraphViewer
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Shift_JIS対応
            System.Text.Encoding.RegisterProvider(
                System.Text.CodePagesEncodingProvider.Instance);

            try
            {
                if (e.Args.Length == 0)
                {
                    var main = new MainWindow(); // empty viewer

                    MainWindow = main;

                    main.Show();

                    return;
                }

                string path = e.Args[0];

                // デバッグ用のハードコードされたパス（起動時にファイルパス渡し）
                //string path = @"C:\Users\yutaka-matumoto.rs\AppData\Local\Temp\GraphViewerDebug\edr_debug_20260608153808.datastream";

                if (!File.Exists(path))
                {
                    MessageBox.Show($"File not found:\n{path}");

                    Shutdown();

                    return;
                }

                List<DatastreamItem>? items = null;

                // ファイルの拡張子を取得して、適切なローダーを選択する
                string extension = Path.GetExtension(path);

                if (extension.Equals(".datastream", StringComparison.OrdinalIgnoreCase))
                {
                    // Load from native .datastream XML
                    items = DatastreamLoader.LoadFromXml(path);
                }
                else if (extension.Equals(".vdtmx", StringComparison.OrdinalIgnoreCase))
                {
                    items = VdtmxLoader.LoadFromXml(path);
                }
                else
                {
                    // Load from JSON list of DTOs
                    string json = File.ReadAllText(path);

                    var dtos = JsonConvert.DeserializeObject<List<DatastreamModelDto>>(json);

                    if (dtos != null && dtos.Any())
                    {
                        items = dtos.Select(dto => new DatastreamItem
                        {
                            Description = dto.Description,
                            Unit = dto.ParamUnit,
                            Points = dto.TimeSeries.Zip(dto.ParamValues, (t, v) =>
                            {
                                if (double.TryParse(t, out var time) && double.TryParse(v, out var val))
                                    return new DatastreamPoint { Time = time, Value = val };

                                return null;
                            }).Where(p => p != null).ToList()
                        }).ToList();
                    }
                }

                if (items == null || !items.Any())
                {
                    MessageBox.Show("No valid data found.");

                    Shutdown();

                    return;
                }

                var mainWindow = new MainWindow(items);

                // ▼ アプリ名取得
                string exeDir = AppDomain.CurrentDomain.BaseDirectory;

                // GraphViewer
                // ↓
                // tools
                // ↓
                // （アプリ名）
                string appRootDir = Path.GetFullPath(
                    Path.Combine(exeDir, @"..\.."));

                string appName = Path.GetFileName(appRootDir);

                // ▼ タイトル設定
                mainWindow.Title = $"{appName} - 詳細グラフ";

                // ▼ アイコン設定
                string iconPath = Path.Combine(
                    appRootDir,
                    "ico",
                    "desktop1.ico");

                if (File.Exists(iconPath))
                {
                    mainWindow.Icon =
                        new System.Windows.Media.Imaging.BitmapImage(
                            new Uri(iconPath));
                }

                // ▼ ファイルパスを渡してアップロード処理を実行する
                mainWindow.ExecuteUpload(path);

                MainWindow = mainWindow;

                mainWindow.Show();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading file:\n" + ex.Message);

                Shutdown();
            }
        }
    }
}