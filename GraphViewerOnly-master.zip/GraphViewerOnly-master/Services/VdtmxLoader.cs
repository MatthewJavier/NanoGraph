﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Linq;
using nanoBT_2nd_for_Windows_GraphViewer.Models;


namespace nanoBT_2nd_for_Windows_GraphViewer.Services
{
    public static class VdtmxLoader
    {
        /// <summary>
        /// VDTMXファイルを読み込み、グラフ表示用のDatastreamItem一覧へ変換する
        /// </summary>
        public static List<DatastreamItem> LoadFromXml(string path)
        {
            // VDTMXファイル読込
            var doc = XDocument.Load(path);

            var items = new List<DatastreamItem>();

            // サンプリングデータ取得
            var sampleNodes = doc.Descendants("s").ToList();

            // 項目定義取得
            var savedataItems =
                doc.Descendants("savedata_dl")
                   .Elements("items")
                   .Elements("item")
                   .ToList();

            // グラフ表示対象のアナログ項目取得
            var analogItems = savedataItems
                .Where(x => x.Attribute("t")?.Value == "ANALOG")
                .ToList();

            // アナログ項目ごとにグラフデータ作成
            foreach (var analogItem in analogItems)
            {
                // 項目インデックス取得
                var indexText = analogItem.Attribute("i")?.Value;

                if (!int.TryParse(indexText, out var index))
                {
                    continue;
                }

                // グラフ項目生成
                var item = new DatastreamItem
                {
                    Description = analogItem.Element("text")?.Value ?? string.Empty,
                    Unit = analogItem.Element("unit")?.Value ?? string.Empty
                };

                // サンプリングデータから時系列データ作成
                foreach (var sample in sampleNodes)
                {
                    // 時刻取得
                    if (!double.TryParse(sample.Attribute("t")?.Value, out var time))
                    {
                        continue;
                    }

                    // インデックスに対応する値取得
                    var valueElement =
                        sample.Elements("v").ElementAtOrDefault(index);

                    var hex =
                        valueElement?.Attribute("f")?.Value;

                    if (string.IsNullOrEmpty(hex))
                    {
                        continue;
                    }

                    // グラフポイント追加
                    item.Points.Add(
                        new DatastreamPoint
                        {
                            Time = time,
                            Value = HexToDouble(hex)
                        });
                }

                // データが存在する項目のみ追加
                if (item.Points.Count > 0)
                {
                    items.Add(item);
                }
            }

            return items;
        }


        public static DatastreamLoadResult LoadWithMetadata(string path)
        {
            return new DatastreamLoadResult
            {
                TripName = Path.GetFileNameWithoutExtension(path),
                // TODO メインアプリからトリガー情報を受け取る
                Trigger = "不明",
                Items = LoadFromXml(path)
            };
        }

        // VDTMXの16進数文字列をdoubleへ変換
        private static double HexToDouble(string hex)
        {
            // 0は数値0として扱う
            if (string.IsNullOrWhiteSpace(hex) || hex == "0")
            {
                return 0;
            }

            // 0xプレフィックス除去
            if (hex.StartsWith("0x"))
            {
                hex = hex[2..];
            }

            // 奇数桁補正
            if (hex.Length % 2 != 0)
            {
                hex = "0" + hex;
            }

            var bytes = Convert.FromHexString(hex);

            // BitConverter用にエンディアン調整
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(bytes);
            }

            return BitConverter.ToDouble(bytes, 0);
        }
    }
}