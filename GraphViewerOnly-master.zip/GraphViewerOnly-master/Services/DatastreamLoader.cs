﻿using System.Globalization;
using System.IO;
using System.Xml.Linq;
using nanoBT_2nd_for_Windows_GraphViewer.Models;

namespace nanoBT_2nd_for_Windows_GraphViewer.Services
{
    public static class DatastreamLoader
    {
        public static List<DatastreamItem> LoadFromXml(string path)
        {
            return LoadWithMetadata(path).Items;
        }

        public static DatastreamLoadResult LoadWithMetadata(string path)
        {
            var doc = XDocument.Load(path);
            var header = doc.Descendants("header").FirstOrDefault();

            var result = new DatastreamLoadResult
            {
                TripName = header?.Element("trip_name")?.Value ?? Path.GetFileNameWithoutExtension(path),
                Trigger = header?.Element("trigger")?.Value ?? "不明"
            };

            var items = doc.Descendants("item").Select(item =>
            {
                var desc = item.Element("description")?.Value ?? string.Empty;
                var unit = item.Element("unit")?.Value ?? string.Empty;
                var points = (item.Element("values")?.Elements("value") ?? Enumerable.Empty<XElement>())
                    .Select(val =>
                    {
                        if (!double.TryParse(val.Attribute("receiving_time")?.Value, NumberStyles.Any, CultureInfo.InvariantCulture, out var time))
                            return null;

                        var raw = val.Value.Trim();
                        // Try to clean the unit off the end
                        var clean = raw;

                        if (!string.IsNullOrEmpty(unit) && raw.EndsWith(unit))
                            clean = raw[..^unit.Length].Trim();

                        return double.TryParse(clean, NumberStyles.Any, CultureInfo.InvariantCulture, out var y)
                            ? new DatastreamPoint { Time = time, Value = y }
                            : null;
                    })
                    .Where(p => p != null).ToList();

                return points.Count > 0
                    ? new DatastreamItem { Description = desc, Unit = unit, Points = points }
                    : null;
            })
            .Where(x => x != null)
            .ToList();

            result.Items = items;

            return result;
        }
    }
}