﻿using nanoBT_2nd_for_Windows_GraphViewer.Constants;
using nanoBT_2nd_for_Windows_GraphViewer.Models;
using nanoBT_2nd_for_Windows_GraphViewer.UI;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Wpf;
using System.Runtime.Intrinsics.X86;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace nanoBT_2nd_for_Windows_GraphViewer.Handlers
{
    internal class OverlayFileDropHandler
    {
        public static bool HandleDrop(
            DragEventArgs e,
            PlotModel overlayModel,
            PlotView overlayPlotView,
            Stack<OxyPlot.Series.Series> overlaySeriesStack,
            Action<DatastreamItem>? onItemPlotted = null

            )
        {

            // （重ねグラフのみ）色が不足した場合に備えて、実線・破線の2種を用意
            var overlayLineStyles = new[]
            {
                LineStyle.Solid,
                LineStyle.Dash
            };

            e.Handled = true;


            if (!e.Data.GetDataPresent("DatastreamItem")) return false;
            if (e.Data.GetData("DatastreamItem") is not DatastreamItem item) return false;
            if (overlayModel.Series.Any(s => s.Title == item.Description)) return false;
            if (item.Points.Count == 0) return false;

            // === 左右の軸を取得 ===
            var leftAxis = overlayModel.Axes
                .OfType<LinearAxis>()
                .FirstOrDefault(a => a.Key == "YL");

            var rightAxis = overlayModel.Axes
                .OfType<LinearAxis>()
                .FirstOrDefault(a => a.Key == "YR");

            if (leftAxis == null || rightAxis == null)
            {
                // 軸がまだ初期化されていない
                // → ここでは何もしない（もしくは return）
                return false;
            }

            // ===== 単位と使用軸の決定=====
            string axisKey;

            bool isRpm = IsRpmUnit(item.Unit);
            bool hasPrimary = !string.IsNullOrEmpty(leftAxis.Title);

            // ① まだ何も表示されていない（1本目）
            if (!hasPrimary)
            {
                leftAxis.Title = item.Unit;   // ← 左軸に単位表示
                axisKey = "YL";
            }
            else
            {
                // 第一単位判定用
                bool primaryIsRpm = IsRpmUnit(leftAxis.Title);

                if (primaryIsRpm)
                {
                    // 第一単位が rpm
                    axisKey = isRpm ? "YL" : "YR";
                }
                else
                {
                    // 第一単位が rpm 以外
                    axisKey = isRpm ? "YR" : "YL";
                }

                // 副軸はスケール専用・非表示
                rightAxis.IsAxisVisible = false;
                rightAxis.TextColor = OxyColors.Transparent;
                rightAxis.AxislineColor = OxyColors.Transparent;
                rightAxis.TicklineColor = OxyColors.Transparent;
                rightAxis.MajorGridlineColor = OxyColors.Transparent;
                rightAxis.MinorGridlineColor = OxyColors.Transparent;
                rightAxis.AxislineThickness = 1;
                rightAxis.MajorGridlineStyle = LineStyle.Solid;
            }

            int colorIndex = overlayModel.Series.Count;

            // ▼ EDR時は小数秒表示、それ以外は整数秒表示
            //string trackerFormat;

            //if (PlotFactory.IsEdrData)
            //{
            //    trackerFormat = $"系列: {{0}}\n受信時刻: {{2:F3}} sec\n値: {{4:0.##}} {item.Unit}";
            //}
            //else
            //{
            //    trackerFormat = $"系列: {{0}}\n受信時刻: {{2}}\n値: {{4:0.##}} {item.Unit}";
            //}

            string trackerFormat = $"系列: {{0}}\n受信時刻: {{2:F3}} sec\n値: {{4:0.##}} {item.Unit}";


            var series = new OxyPlot.Series.StairStepSeries
            {
                Title = item.Description,
                YAxisKey = axisKey,
                StrokeThickness = AppConstants.OverlayGraphLineThickness,
                Tag = item,

                // (重ねグラフのみ)色パレット（赤・青・緑）が一周するごとに実線／破線を切り替える
                LineStyle = overlayLineStyles[
                    (colorIndex / AppConstants.SeriesColorPalette.Length)
                    % overlayLineStyles.Length
                ],

                MarkerType = AppConstants.OverlayGraphMarkerType,
                MarkerSize = AppConstants.OverlayGraphMarkerSize,
                TrackerFormatString =trackerFormat,
                Color = AppConstants.SeriesColorPalette[colorIndex % AppConstants.SeriesColorPalette.Length],
            };

            series.Points.AddRange(item.Points.Select(p => new DataPoint(p.Time, p.Value)));

            overlayModel.Series.Add(series);

            // Undo 用に記録
            overlaySeriesStack.Push(series);

            // 「この item がグラフに入った」という事実を通知
            onItemPlotted?.Invoke(item);

            // 軸と表示領域はここ一か所で決定
            OverlayPlotManager.UpdateZoomPanState(overlayModel);

            // 再描画（再構築しない）
            overlayModel.InvalidatePlot(false);

            return true;
        }

        private const string UnitUndefined = "__UNDEFINED__";

        private static string NormalizeUnit(string unit)
        {
            if (string.IsNullOrWhiteSpace(unit))
                return UnitUndefined;

            return unit.Trim();
        }

        // rpm と r/min を同一視するための補助関数（必要に応じて拡張）
        public static bool IsRpmUnit(string? unit)
        {
            if (string.IsNullOrWhiteSpace(unit))
                return false;

            return unit.Equals("rpm", StringComparison.OrdinalIgnoreCase)
                || unit.Equals("r/min", StringComparison.OrdinalIgnoreCase);
        }


    }
}