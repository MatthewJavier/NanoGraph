﻿using System.Windows;
using System.Windows.Controls;
using WpfSeries = OxyPlot.Wpf;

namespace nanoBT_2nd_for_Windows_GraphViewer.Handlers
{
    public static class ClearMenuHandler
    {
        public static void ClearMenuClick(

            Grid dataItemTable,
            StackPanel graphPanel,
            ComboBox graphModeSelector,
            Button stepBackButton,
            Button playPauseButton,
            Button stepForwardButton,
            Button deleteCheckpointButton,
            Button resetCheckpointButton,
            Slider timeSlider,
            Dictionary<CheckBox, WpfSeries.PlotView> plotMap,
            Dictionary<string, OxyPlot.Series.StairStepSeries> seriesMap,
            WpfSeries.PlotView overlayPlotView,
            Panel overlayPanel)
        {
            dataItemTable.RowDefinitions.Clear();
            dataItemTable.Children.Clear();

            graphPanel.Children.Clear();

            plotMap.Clear();

            seriesMap.Clear();

            graphModeSelector.IsEnabled = false;

            stepBackButton.IsEnabled = false;

            playPauseButton.IsEnabled = false;

            stepForwardButton.IsEnabled = false;

            deleteCheckpointButton.IsEnabled = false;

            resetCheckpointButton.IsEnabled = false;

            timeSlider.IsEnabled = false;

            overlayPlotView.Model = null;

            overlayPanel.Visibility = Visibility.Collapsed;

            graphPanel.Visibility = Visibility.Visible;
        }
    }
}