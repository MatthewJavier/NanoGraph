﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using nanoBT_2nd_for_Windows_GraphViewer.Models;
using nanoBT_2nd_for_Windows_GraphViewer.Services;
using nanoBT_2nd_for_Windows_GraphViewer.UI;
using WpfSeries = OxyPlot.Wpf;
using System.IO;

namespace nanoBT_2nd_for_Windows_GraphViewer.Handlers
{
    public static class UploadMenuHandler
    {
        public static void UploadMenuClick(
            Window owner,
            Grid dataItemTable,
            Grid fixedAreaGrid,
            StackPanel graphPanel,
            ComboBox graphModeSelector,
            Button playPauseButton,
            Button ResetPlaybackButton,
            Button stepBackButton,
            Button stepForwardButton,
            Button deleteCheckpointButton,
            Button resetCheckpointButton,
            Slider timeSlider,
            Dictionary<CheckBox, WpfSeries.PlotView> plotMap,
            Func<DatastreamItem, bool, Grid> createPlotViewWithMode,
            Action<CheckBox, RoutedEventHandler> bindCheckboxHandler,
            Action<string, string> setMetadataLabels,
            bool isOverlayMode = true,
            string overridePath = null
        )
        {
            string path;

            // ▼ 外部からパスが渡されている場合はそれを優先
            if (!string.IsNullOrEmpty(overridePath))
            {
                path = overridePath;
            }
            else
            {
                // ▼ 手動時は従来通りダイアログで取得
                var ofd = new OpenFileDialog
                {
                    Filter ="Supported Files (*.datastream;*.vdtmx)|*.datastream;*.vdtmx|" +
                            "Datastream Files (*.datastream)|*.datastream|" +
                            "VDTMX Files (*.vdtmx)|*.vdtmx",
                    Title = "Select a data file"
                };

                if (ofd.ShowDialog(owner) != true)
                {
                    return;
                }

                path = ofd.FileName;
            }

            // ▼ ロード中表示開始
            var main = owner as MainWindow;

            if (main != null)
            {

                main.LoadingOverlay.Visibility = Visibility.Visible;
                main.Dispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.Render);
            }

            // ▼ 重い処理を別スレッドへ（ロード中表示安定化のため）
            Task.Run(() =>
            {
                var extension = Path.GetExtension(path);

                DatastreamLoadResult result;

                if (extension.Equals(".datastream", StringComparison.OrdinalIgnoreCase))
                {
                    result = DatastreamLoader.LoadWithMetadata(path);
                }
                else if (extension.Equals(".vdtmx", StringComparison.OrdinalIgnoreCase))
                {
                    result = VdtmxLoader.LoadWithMetadata(path);
                }
                else
                {
                    throw new NotSupportedException(
                        $"Unsupported file type: {extension}");
                }
                main.Dispatcher.Invoke(() =>
                {


                    setMetadataLabels(result.TripName, result.Trigger);

                    GraphPanelManager.Populate(
                        dataItemTable,
                        fixedAreaGrid,
                        graphPanel,
                        graphModeSelector,
                        playPauseButton,
                        ResetPlaybackButton,
                        stepBackButton,
                        stepForwardButton,
                        deleteCheckpointButton,
                        resetCheckpointButton,
                        timeSlider,
                        result.Items,
                        plotMap,
                        item => createPlotViewWithMode(item, isOverlayMode),
                        bindCheckboxHandler
                    );

                    var mw = main as MainWindow;
                    if (mw != null)
                    {
                        mw.InitializePlaybackAfterPopulate();
                    }

                    // ▼ ロード中表示終了（ここだけ追加）
                    if (main != null)
                    {
                        main.LoadingOverlay.Visibility = Visibility.Collapsed;

                        // ロード終了後にガイド表示更新
                        main.UpdateOverlayGuideVisibility();
                    }

                });
            });


        }
    }
}